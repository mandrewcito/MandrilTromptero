#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

import nltk
import pickle

from collections import defaultdict
from miopia.preprocessor.PreProcessor import PreProcessor
from miopia.preparator.LexicalProcessor import LexicalProcessor
from miopia.preparator.TextPreparator import TextPreparator
from miopia.parser.Parser import Parser
from miopia.analyzer.Dictionary import Dictionary
from miopia.analyzer.SentimentAnalyzer import SentimentAnalyzer
from miopia.analyzer.LinguisticAnalyzer import LinguisticAnalyzer
from miopia.analyzer.LinguisticInfo import LinguisticInfo
from miopia.analyzer.AnalyzerConfiguration import AnalyzerConfiguration
from miopia.util.ConfigurationManager import ConfigurationManager
from miopia.classifier.SimpleClassifier import SimpleClassifier
from miopia.classifier.TernaryStrategy import TernaryStrategy
from miopia.classifier.SMOStrategy import SMOStrategy
from miopia.adapter.SentimentAdapter import SentimentAdapter
from miopia.adapter.PsychometricAdapter import PsychometricAdapter
from miopia.adapter.CompositeAdapter import CompositeAdapter
from miopia.adapter.NGramAdapter import NGramAdapter
from miopia.adapter.Feature import FeatureTypeConfiguration
from miopia.adapter.Feature import FeatureLevelBackOff
from miopia.adapter.Feature import SentimentFeature
from nltk.tokenize.punkt import PunktWordTokenizer
from miopia.classifier.PolarityType import PolarityType

import os
import codecs


def get_linguistic_info_category(path_training_dir,linguistic_analyzer):
    list_linguistic_info_category = []
    categories = os.listdir(path_training_dir)    
    for category in categories:
        files = os.listdir(path_training_dir+category)
        for fi in files:
            linguistic_info = linguistic_analyzer.analyze_from_conll(path_training_dir+category+"/"+fi)[1]
            list_linguistic_info_category.append((linguistic_info,category))
    return list_linguistic_info_category
          

PATH_WEKA = ConfigurationManager().getParameter("path_weka")
PATH_RANKING_FILE_FEATURES = "/tmp/ranking_SENTIMENT.PSYCHOMETRIC"
#It will be also the test set (just to show how it works)
PATH_DUMMY_TRAINING_SET = "/usr/local/lib/python2.7/dist-packages/miopia-0.1.0-py2.7.egg/miopia/dataresources/dummy_training_set/"
PATH_OUTPUT_ARFF = "/tmp/outputARFF.arff" 
PATH_WEKA_MODEL = '/tmp/classifier_model'

preprocessor = PreProcessor()
preparator = TextPreparator()
sentence_tokenizer = nltk.data.load('tokenizers/punkt/spanish.pickle')
tokenizer = PunktWordTokenizer()
tagger = pickle.load(open(ConfigurationManager().getParameter("path_pickle_taggers")+"spanish_brill.pickle",'r'))
parser = Parser()
dictionary = Dictionary()
lexical_processor = LexicalProcessor(sentence_tokenizer,
                                     tokenizer,
                                     tagger)

s =  SentimentAnalyzer(parser,
                       dictionary,
                       AnalyzerConfiguration(final_sentences_weight=1.),
                       preprocessor,
                       lexical_processor)

sentiment_adapter = SentimentAdapter(0.,FeatureTypeConfiguration(),
                                     [SentimentFeature.NEG_WORDS,
                                     SentimentFeature.POS_WORDS,
                                     SentimentFeature.SEMANTIC_ORIENTATION],
                                     PATH_WEKA) 

psychometric_adapter = PsychometricAdapter(0.,FeatureTypeConfiguration(),PATH_WEKA)
unigram_adapter = NGramAdapter(0.,FeatureTypeConfiguration(n_gram_back_off= FeatureLevelBackOff.TYPE_BACK_OFF_LEMMA,
                                                                n_gram=1),PATH_WEKA)    
composite_adapter = CompositeAdapter(0.,PATH_WEKA)

composite_adapter.add(sentiment_adapter)
composite_adapter.add(psychometric_adapter)
composite_adapter.add(unigram_adapter)
dict_features = composite_adapter.adapt(PATH_DUMMY_TRAINING_SET,PATH_RANKING_FILE_FEATURES)

linguistic_analyzer = LinguisticAnalyzer(parser,dictionary,dict_features,preprocessor,lexical_processor)
strategy = SMOStrategy([PolarityType.POSITIVE, PolarityType.NEGATIVE,PolarityType.NONE],PATH_WEKA) 
strategy.train(get_linguistic_info_category(PATH_DUMMY_TRAINING_SET,linguistic_analyzer),dict_features,PATH_OUTPUT_ARFF,PATH_WEKA_MODEL)
classifier = SimpleClassifier(linguistic_analyzer,strategy,[],None)

#We evaluate the test set (in ConLL 2006 format)
list_polarities = [polarity_type for polarity_type in os.listdir(PATH_DUMMY_TRAINING_SET)]

#To classify an list of files
for polarity in list_polarities:
    print "Files with polarity:",polarity
    dict_id_polarities = classifier.classify([PATH_DUMMY_TRAINING_SET+polarity+"/"+name_file for name_file in os.listdir(PATH_DUMMY_TRAINING_SET+polarity)]) 
    print dict_id_polarities

#To classify a text from its string
print classifier.classify_from_info(linguistic_analyzer.analyze("Esta máquina es muy barata, pero pésima".decode('utf-8'))[1],dict_adapted_features=dict_features);

