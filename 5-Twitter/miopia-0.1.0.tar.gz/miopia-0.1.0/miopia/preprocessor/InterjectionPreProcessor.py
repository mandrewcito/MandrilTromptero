'''
Created on 06/02/2013

@author: David Vilares Calvo
'''

from miopia.preprocessor.PreProcessorDecorator import PreProcessorDecorator
import re

class InterjectionPreProcessor(object):
    '''
    classdocs
    '''


    def __init__(self,component):
        '''
        Constructor
        '''
        self._component = component
        
        
    def preprocess(self,text):
        """
        @param text: A String.
        @return A processed string with normalised laughs
        """
        return self._component.preprocess(self._normalize_laughs(text))
        
        
    def _normalize_laughs(self,text):
        
        
        def normalise_laugh(vocal,text):
            
            regex = '[jJ'+vocal+vocal.upper()+']{4,}'      
            laughs =  re.findall(regex,text)
            normalised_cap_laugh = 'J'+vocal.upper()+'J'+vocal.upper()
            normalised_lower_laugh = 'j'+vocal+'j'+vocal
            for laugh in laughs:
                #otherwise is no really a laugh
                if laugh.find('j') != -1 or laugh.find('J') != -1:        
                    if laugh.isupper(): 
                        text = text.replace(laugh,normalised_cap_laugh)
                    else: 
                        text = text.replace(laugh,normalised_lower_laugh)  
            return text
        
        for vocal_laugh in ['a','e','i','o','u']:
            text = normalise_laugh(vocal_laugh,text)
                   
        return text
        