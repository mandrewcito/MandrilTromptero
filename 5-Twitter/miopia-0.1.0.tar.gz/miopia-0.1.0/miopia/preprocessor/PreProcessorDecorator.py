'''

@author: David Vilares Calvo 
'''

from PreProcessorI import *

class PreProcessorDecorator(PreProcessorI):
    '''
    classdocs
    '''


    def __init__(self,params):
        '''
        Constructor
        '''
        raise NotImplementedError
        
        
    def preprocess(self,text):
        raise NotImplementedError
        