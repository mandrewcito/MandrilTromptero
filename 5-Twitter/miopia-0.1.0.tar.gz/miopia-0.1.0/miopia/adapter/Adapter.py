'''
Created on 10/04/2013

@author: David Vilares Calvo
'''

import os
import codecs
from miopia.adapter.Feature import FeatureTypeConfiguration
from miopia.util.ConfigurationManager import ConfigurationManager
from collections import OrderedDict

class FeatureInfo(object):
    """
    This class provides information about a feature for a supervised classifier
    """
    
    def __init__(self,feature,ranking,information_gain,feature_type):
        """
        @param feature: The idenfier of the feature. A string
        @param ranking: The ranking of the feature with respect to the others. A float
        @param information_gain: A float indicating the information gain provided by the feature
        @param feature_type: A constant of L{FeatureType} which represents the type of the feature
        """
        self._feature = feature
        self._ranking = ranking
        self._information_gain = information_gain
        self._feature_type = type
        
    def get_feature(self):
        """
        @return: A string with the feature
        """
        return self._feature
    
    def get_ranking(self):
        """
        @return: A float with the ranking of the feature
        """
        return self._ranking
    
    def get_feature_type(self):
        """
        @return: An constant of L{FeatureType} which represents the type of the feature
        """
        return self._feature_type
    
    def get_information_gain(self):
        """
        @return: A float
        """
        return self.get_information_gain()


class Adapter(object):
    #TODO: Any adapter can read any adapter ranking file , is this good?
    '''
    Adapter is an abstract class which defines the interface for different features Adapter's
    provided in the package adapter
    '''

    DELIMITER_FEATURE_TYPE_AND_LIST_FEATURES = ":"
    ALLOWED_JAVA_HEAP_XMX = ConfigurationManager().getParameter("allowed_java_heap")

    def __init__(self,float_threshold, feature_type_configuration, path_weka, arff_file):
        '''
        Constructor
        @param float_threshold: The minimum information gain needed to select a feature
        @param feature_type_configuration: An instance of L{miope.adapter.Feature.FeatureTypeConfiguration}
        @param path_weka: The path to the weka.jar
        @param arr_file: The destination path to an auxiliary arff file
        '''
        self._threshold = float_threshold
        self._arff_file = arff_file
        self._feature_type_configuration = feature_type_configuration
        if path_weka is None: self._path_weka =''
        else: self._path_weka = path_weka
    
    def get_feature_type_configuration(self):
        """
        @return: An instance of L{FeatureTypeConfiguration}
        """
        return self._feature_type_configuration
    
    def get_arff_file(self):
        """
        @return: The name of the arff file used by the adapter
        """
        return self._arff_file
    
    
    def count_features(self,dg):
        """
        @return A dictionary with the number of features considered by the adapter in an instance
        of a L{SentimentDependencyGraph} 
        """
        raise NotImplementedError
    
    
    def features(self,training_dir):
        """
        @param training_dir: A directory according the TextDirectoryLoader proposed by WEKa
        dir
        |dir_category1
        |dir_category2
        |...
        |dir_categoryn
        @return: A dictionary of {L{FeatureType},L{FeatureTypeConfiguration}: NameFeature } where
        NameFeature is a string.
        """
        self._to_arff(training_dir)
        return self.features_from_arff(self._arff_file)
    
    
    def features_from_arff(self,arff_file):
        """
        @param ranking_file:  A path to an existing ranking file
        @precondition: ranking_file must be in the format provided by the WEKA selection attribute tools
        @return: A dictionary of {L{FeatureType},L{FeatureTypeConfiguration}: NameFeature } where
        NameFeature is a string.
        """
        dict_features = OrderedDict()

        lines_aux = codecs.open(arff_file,"r").read().split(
                        '@DATA')[0].split('\n')

        lines_attributes = lines_aux[1:len(lines_aux)-2]
        for l in lines_attributes:
            l_splitted = l.replace('\'','').split()
            feature = l_splitted[1]
            feature_type, ftc, name = self._get_feature_configuration(feature) #get_feature_type_and_name_from_composite_name(key_atr)
            try: 
                dict_features[feature_type, ftc].append(name) 
            except KeyError:
                dict_features[feature_type, ftc] = [name]        
        return dict_features           
    
    
#     def features_from_arff(self,arff_file):
#         """
#         @return: The features include in the header of the arff_file
#         """
#         dict_features = {}
#         lines_aux = codecs.open(self._arff_file,"r").read().split(
#                         '@DATA')[0].split('\n')
# 
#         lines_attributes = lines_aux[1:len(lines_aux)-2]
#         for l in lines_attributes:
#             l_splitted = l.replace('\'','').split()
#             feature = l_splitted[1].rsplit(FeatureTypeConfiguration.DELIMITER_CONFIGURATION) 
#             feature_name = feature[len(feature)-1]    
#             try:
#                 dict_features[self._get_feature_type(), self._feature_type_configuration].append(feature_name) 
#             except KeyError:
#                 dict_features[self._get_feature_type(), self._feature_type_configuration] = [feature_name]
#         return dict_features  
#     
    
    def adapt(self,training_dir, ranking_file):
        """
        It obtains a dictionary with the best features considered by the an L{Adapter}, given a training dir.
        Results are printed in the ranking file.
        @param training_dir: A directory according the TextDirectoryLoader proposed by WEKa
        dir
        |dir_category1
        |dir_category2
        |...
        |dir_categoryn
        @param ranking_file: A path to the destination ranking file of the features
        @return: A dictionary of {L{FeatureType},L{FeatureTypeConfiguration}: NameFeature } where
        NameFeature is a string.
        """
        self._to_arff(training_dir)
        self._filter(ranking_file)
        self._classify_features(ranking_file)  
        return self._get_features(ranking_file)
    
    def adapt_from_ranking_file(self,ranking_file):
        """
        If obtains a dictionary with the best features considered by an L{Adapter}, given the ranking_file
        provided by WEKA
        @precondition: the ranking_file must be in the format provided by the WEKA selection attribute tools
        @param ranking_file:  A path to an existing WEKA ranking features file
        @return: A dictionary of {L{FeatureType},L{FeatureTypeConfiguration}: NameFeature } where
        NameFeature is a string.
        """
        return self._get_features(ranking_file)

    
    def _to_arff(self,training_dir):
        """
        @param training_dir: The training directory. It must be structured as follows:
        directory
        |directory_category1:
            file1.1
            ...
            file1.n
        ....
        |directory_categoryn:
            filen.1
            ....
            filen.m 
        """
        os.system("java -cp "+self._path_weka+
        " weka.core.converters.TextDirectoryLoader -dir "+training_dir+
        " > "+self._arff_file)


    def _to_arff_data(self,dict_features,dict_features_file, 
                      dict_category_file, categories,number_files):
        """
        @param dict_features: 
        @param dict_feature_file: d[id_file][] Tee list of occurrence of each feature in a fil
        @param dict_category_file:
        @param categories:
        @param number_files: 
        """
        
        farff = open(self._arff_file,"w")
        farff.write("@RELATION "+self._get_feature_type()+"Relation\n")

        dict_id_features = {}
        id_feature = 0 
        for feature_type, ftc in dict_features.keys():        
            for feature_name in dict_features[feature_type, ftc]:      
                feature = feature_type+str(ftc)+feature_name     
                farff.write("@ATTRIBUTE '"+feature.encode('utf-8')+"' "+ftc.get_weka_data_type()+"\n")
                dict_id_features[feature] = id_feature
                id_feature+=1     
        farff.write("@ATTRIBUTE 'class' {"+','.join(categories)+"}\n")
        farff.write("@DATA\n")         
        
        for i in range(0,number_files):     
            arff_data_file = ''
            open_symbol = "{"
            close_symbol = "}"

            keys  = dict_features_file[i].keys()
            keys.sort(key = lambda x: dict_id_features[x]) 

            for feature_in_text in keys:                            
                arff_data_file+=open_symbol+str(dict_id_features[feature_in_text])+" "+str(dict_features_file[i][feature_in_text])+","    
                open_symbol = ""

            arff_data_file+=open_symbol+str(id_feature)+" "+dict_category_file[i]+close_symbol+'\n'
            farff.write(arff_data_file)               
            
    
    def _filter(self,ranking_file):
        """
        It applies a filter over the features stored in a ranking file
        """
        pass
    
    def _classify_features(self, ranking_file):
        """
        It ranks features according to their information gain
        """
        os.system("java -Xmx"+self.ALLOWED_JAVA_HEAP_XMX+" -cp "+self._path_weka+
                  " weka.attributeSelection.InfoGainAttributeEval "+
                  " -s \"weka.attributeSelection.Ranker -T "+
                  "-1.7976931348623157E308 -N -1\" "+
                  "-i "+self._arff_file+" > "+ranking_file
                  ) 
    
    def _get_feature_type(self):
        """
        The type of the feature
        """
        raise NotImplementedError


    def _get_features(self,ranking_file):   
        """
        @param ranking_file:  A path to an existing ranking file
        @precondition: ranking_file must be in the format provided by the WEKA selection attribute tools
        @return A dictionary of features given a ranking file provided by WEKA attribute selection tools
        """

        dict_features = {}
        lines_aux = codecs.open(ranking_file,"r",'utf-8').read().split(
                        'Selected attributes:')[0].split('\n')

        lines_attributes = lines_aux[11:len(lines_aux)-2]
        for l in lines_attributes:
            l_splitted = l.split()
            information_gain,_,key_atr = float(l_splitted[0]), l_splitted[1], l_splitted[2]  
            #We only select attributes with a positive information gain        
            if information_gain > self._threshold:
                feature_type, ftc, name = self._get_feature_configuration(key_atr) 
                
                try: 
                    dict_features[feature_type, ftc].append(name) 
                except KeyError:
                    dict_features[feature_type, ftc] = [name]   
        return dict_features
    
    
    
    def _get_feature_configuration(self,str_name_feature):
        """
        Given a long name of a feature it returns the L{FeatureType}
        and the L{FeatureTypeConfiguration}
        """
            
        aux = str_name_feature.rsplit(FeatureTypeConfiguration.DELIMITER_CONFIGURATION)
        back_off_head = None
        back_off_dependent = None
        n_gram = None
        feature_type_configuration = aux[1:(len(aux)-1)]
        kwargs = {}
        for configuration_element in feature_type_configuration:
                
            if configuration_element.startswith(FeatureTypeConfiguration.HEAD_BACK_OFF_DELIMITER+"="):
                back_off_head = configuration_element[len(FeatureTypeConfiguration.HEAD_BACK_OFF_DELIMITER+"="):]

            if configuration_element.startswith(FeatureTypeConfiguration.DEPENDENT_BACK_OFF_DELIMITER+"="):
                back_off_dependent = configuration_element[len(FeatureTypeConfiguration.DEPENDENT_BACK_OFF_DELIMITER+"="):]

            if configuration_element.startswith(FeatureTypeConfiguration.N_GRAM_DELIMITER+"="):
                n_gram = configuration_element[len(FeatureTypeConfiguration.N_GRAM_DELIMITER+"="):]
                kwargs['n_gram'] = n_gram
                
            if configuration_element.startswith(FeatureTypeConfiguration.N_GRAM_BACK_OFF_DELIMITER+"="):
                n_gram_back_off = configuration_element[len(FeatureTypeConfiguration.N_GRAM_BACK_OFF_DELIMITER+"="):]
                kwargs['n_gram_back_off'] = n_gram_back_off
                    
            if configuration_element.startswith(FeatureTypeConfiguration.ADD_DEPENDENCY_TYPE_DELIMITER+"="):
                add_dependency_type = configuration_element[len(FeatureTypeConfiguration.ADD_DEPENDENCY_TYPE_DELIMITER+"="):]
                kwargs['add_dependency_type'] = True if add_dependency_type == 'True' else False
        feature_type_configuration = FeatureTypeConfiguration(back_off_head,
                                                              back_off_dependent,
                                                              **{str(k): v for k, v in kwargs.items()})
                   
        return aux[0],feature_type_configuration,aux[len(aux)-1]  