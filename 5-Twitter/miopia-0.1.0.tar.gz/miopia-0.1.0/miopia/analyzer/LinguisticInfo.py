'''
Created on 21/02/2013

@author: David Vilares Calvo
'''

class LinguisticInfo(object):
    '''
    classdocs
    '''


    def __init__(self, list_features):
        '''
        @param list_features: A list of L{Feature} 
        '''

        self._features = list_features
        
    
    def get_features(self):
        return self._features
    
    def set_features(self, list_features):
        self._features = list_features

        