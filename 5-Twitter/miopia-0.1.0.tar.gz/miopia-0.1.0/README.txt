
INSTALLATION

NOTE: Miope requires Python 2.7

1. Install setuptools -> https://pypi.python.org/pypi/setuptools
2. Install Natural Language Toolkit (NLTK) and their dependencies -> http://nltk.org/install.html
3. Install nltk_data (the tokenizers module) -> http://nltk.org/data.html 
4. Download MaltParser 1.7.2 -> http://www.maltparser.org/download.html
5. Unzip MaltParser in your desired directory (e.g /opt/maltparser/MaltParser-1.7.2)
6. Download Weka (e.g. 3-7-10) -> http://www.cs.waikato.ac.nz/ml/weka/downloading.html
7. Unzip Weka in your desired directory (e.g /opt/weka/weka-3-7-10)
8. Unzip miope-0.1.0.tar.gz (if you didn't it yet)
9. Modify the file miope/miope.conf to establish the path to the maltparser-1.7.2.jar and weka.jar (parameter path_maltparser)
10. Install miope-0.1.0 executing -> sudo python setup.py install
-------------------------------------------------------------------------------------------------------

DEMO

If you have been able to complete all installation steps, take a look to the demos located in:

/usr/local/lib/python2.7/dist-packages/miope-0.1.0-py2.7.egg/demo

Execute

python demo_unsupervised_miope.py

and

python demo_supervised_miope.py