'''
@author: David Vilares Calvo
'''

class InfoTag(object):

    """
    Auxiliary structure for saving information of a word tag
    """

    def __init__(self,cpostag,postag,feats):
        """
        Constructor
        """
        self.__cpostag = cpostag
        self.__postag = postag
        self.__feats = feats
    
    def get_cpostag(self):
        return self.__cpostag
    
    def get_postag(self):
        return self.__postag
    
    def get_feats(self):
        return self.__feats
    
    def __str__(self):
        return self.__cpostag+" "+self.__postag+" "+self.__feats