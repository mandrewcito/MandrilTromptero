'''
Created on 11/04/2013

@author: David Vilares Calvo
'''

from miopia.adapter.Adapter import Adapter
from miopia.analyzer.LinguisticAnalyzer import LinguisticAnalyzer
from miopia.parser.Parser import Parser
from miopia.analyzer.Dictionary import Dictionary
from collections import defaultdict
import os

class NLPAdapter(Adapter):
    '''
    NLPAdapter is an abstract class of L{Adapter}
    '''

    def __init__(self,float_threshold,feature_type_configuration,path_weka,arff_file):
        '''
        @param float_threshold: An information gain threshold (minimum) for selecting features
        @param feature_type_configuration: An instance of L{FeatureTypeConfiguration}
        @param path_weka: A path to the weka.jar
        @param arff_file: A path to the destination arff file
        '''
        self._parser = Parser()
        self._linguistic_analyzer = LinguisticAnalyzer(self._parser,Dictionary(),None)
        super(NLPAdapter,self).__init__(float_threshold, feature_type_configuration, path_weka, arff_file)
         

    def _analyze_graph(self, dg):
        raise NotImplementedError


    def count_features(self,dg):
        """
        @param dg: An instance of L{SentimentDependencyGraph}
        @warning: This function returns a modified dictionary of features,
        where the name of the feature (the value of the dictionary) is expanded including its L{FeatureTypeConfiguration}.
        The aim is avoiding duplicates when using a L{CompositeAdapter}.
        @return: A dictionary with the number of features considered by the adapter in an instance
        of a L{SentimentDependencyGraph} 
        """
        dict_features = self._analyze_graph(dg)
        dict_long_title_features = {}
        
        str_feature_type_configuration = str(self.get_feature_type_configuration())
        dict_long_title_features.update({str(self._get_feature_type())
                                        +str_feature_type_configuration
                                        +feature:dict_features.get(feature) 
                                        for feature in set(dict_features)})
        return dict_long_title_features
    

     
    def _to_arff(self,training_dir):
        """
        @param training_dir: The training directory. Files must be in CoNLL-2006 format. 
        The directory mus be structured as follows:
        Category1:
            file1.1
            ...
            file1.n
        ....
        Categoryn:
            filen.1
            ....
            filen.m 
        """
        WEKA_RESERVED_WORDS = ['class']
        file_id = 0
        set_features = set([])
        dict_info_features = {}
        dict_features_file = defaultdict(defaultdict)
        dict_category_file = {}
        categories = os.listdir(training_dir)
        for c in categories:
            files_c = os.listdir(training_dir+"/"+c)
            for f in files_c:
                dict_category_file[file_id] = c              
                dependency_graphs = self._parser.parse_from_conll(training_dir+"/"+c+"/"+f)
                for dg in dependency_graphs:
                    dict_features = self.count_features(dg) #self._analyze_graph(dg)
                    for feature in dict_features:
                        if feature in WEKA_RESERVED_WORDS:
                            continue 
                     #   print feature
                        feature_type, configuration, name =  self._get_feature_configuration(feature)
                        if feature not in set_features:
                            try:
                                dict_info_features[feature_type, configuration].append(name)
                            except:
                                dict_info_features[feature_type, configuration] = [name]
                            set_features.add(feature)
                        try:
                            dict_features_file[file_id][feature]+=dict_features[feature] 
                        except:
                            dict_features_file[file_id][feature] =dict_features[feature]
                file_id+=1    

        self._to_arff_data(dict_info_features, dict_features_file, dict_category_file, categories, file_id)    


     
            