'''
Created on 02/07/2012

@author: david.vilares
'''

class UnknownSOException(Exception):
    '''
    classdocs
    '''


    def __init__(self,value):
        '''
        Constructor
        '''
        self.value = value