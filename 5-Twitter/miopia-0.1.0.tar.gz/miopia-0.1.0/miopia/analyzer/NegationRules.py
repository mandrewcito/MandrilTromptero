'''
@author: David Vilares Calvo
'''

class NegationRules:
    verb,branch,default = range(3)