#-*- coding: utf-8 -*-

'''
@author: David Vilares Calvo
'''
import re
from miopia.preprocessor.PreProcessorDecorator import PreProcessorDecorator
from time import time


class HashTagProcessor(PreProcessorDecorator):
    '''
    classdocs
    '''
    
    def __init__(self,component):
        '''
        Constructor
        @param component: An instance defined by the interface L{PreProcessorI}
        '''
        self._component = component
        self._hashtag_pattern = re.compile(r'(#\w{1,})') 
    
        
    def preprocess(self,text):
        """
        @param text: A tweet as a string
        @return A hashtag processed tweet
        """
        return self._component.preprocess(self._process_hashtag(text))
    
    
    def _process_hashtag(self,text):
        """
        @param text: A tweet. It is a String
        Eliminate the complete hashtag if there is at the beginning
        or the end of the text. Otherwise, only delete '#' symbol.
        Special hashtags as #FF always represented without #, never deleted.
        """
        set_special_hashtags = (['#FF','#ff'])
        #TODO: #ff (and #FF) capitalised but not must count as an intensifier
#        start = time()
        #hashtags = re.findall(r'(#\w{1,})',text)
        hashtags = self._hashtag_pattern.findall(text)
#        print "Hashtag pattern construction", time()-start
        for hashtag in hashtags:
            if ( (text.startswith(hashtag) or text.endswith(hashtag))
                 and hashtag.upper() not in set_special_hashtags):
                text = text.replace(hashtag,'')
            else:
                if hashtag in set_special_hashtags:
                    text = text.replace(hashtag,hashtag[1:].upper()) 
                else: 
                    text = text.replace(hashtag,hashtag[1:])
        return text
        