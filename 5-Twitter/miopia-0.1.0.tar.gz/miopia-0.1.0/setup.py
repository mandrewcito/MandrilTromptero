
from setuptools import setup, find_packages

##
## Prevent setuptools from trying to add extra files to the source code
## manifest by scanning the version control system for its contents.
##
from setuptools.command import sdist
del sdist.finders[:]

setup(
   name = "miopia",
    version = "0.1.0",
    author = "David Vilares Calvo",
    author_email = "david.vilares@udc.es",
    description =  'Sentiment Analysis and Opinion Mining',
    long_description = 'This packages provides sentiment analysis functionalities taking into account the syntactic structure of texts',
    url = 'www.fic.udc.es',
    packages = ['miopia',
        'miopia.parser',
        'miopia.tagger',
        'miopia.preparator',
        'miopia.adapter',
        'miopia.preprocessor',
        'miopia.analyzer',
        'miopia.util.exceptions',
        'miopia.classifier',
        'demo',
        'api'],
    py_modules = [  'miopia.util.ConfigurationManager',
                    'miopia.util.BinaryTree'],
    include_package_data=True,
    data_files = [('/etc', ['miopia/miopia.conf'])],
    zip_safe=False,
 classifiers = [ 'Programming Language :: Python :: 2.7']
)
