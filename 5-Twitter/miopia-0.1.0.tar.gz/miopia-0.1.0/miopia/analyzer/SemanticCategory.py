'''
@author: David Vilares Calvo
'''

class SemanticCategory(object):
    '''
    classdocs
    '''
    ADJECTIVE = "ADJECTIVE" 
    ADVERB = "ADVERB"
    EMOTICON = "EMOTICON"
    INTENSIFIER = "INTENSIFIER"
    NEGATION = "NEGATION"
    NEGATION_WITHOUT = "NEGATION_WITHOUT" 
    NOUN = "NOUN"
    OTHER = "OTHER"
    SUBORDINATE_ADVERSATIVE = "SUBORDINATE_ADVERSATIVE"
    VERB = "VERB"