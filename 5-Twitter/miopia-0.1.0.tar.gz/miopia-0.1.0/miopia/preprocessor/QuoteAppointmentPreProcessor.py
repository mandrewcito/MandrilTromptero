'''
Created on 10/12/2012

@author: david.vilares
'''
import re
from PreProcessorDecorator import *


class QuoteAppointmentPreProcessor(PreProcessorDecorator):
    '''
    classdocs
    '''

    def __init__(self,component):
        '''
        Constructor
        '''
        self.component = component
        
    def preprocess(self,text):
        
        ptext = self.component.preprocess(text)
        return self._process_quote_appointments(ptext)
        
    
#    def _process_quote_appointments(self,lines):
#        
#        def quote_transformation(quote):
#            words = quote.split()         
#            return '_'.join(words)[:-1]+unicode('_QUOTE"')
#       
#        plines = []
#        quote_pattern = re.compile(u'\"[a-zA-Z ;\u00C0-\uFFFF]+\"')
#        for l in lines:
#            quotes = quote_pattern.findall(l)
#            for q in quotes:
#                l = l.replace(q, quote_transformation(q))
#                plines.append(l)         
#        return plines
    
    
    def _process_quote_appointments(self,text):
     
        def quote_transformation(quote):
            words = quote.split()         
            return '_'.join(words)[:-1]+unicode('_QUOTE"')
       
        quote_pattern = re.compile(u'\"[a-zA-Z ;\u00C0-\uFFFF]+\"')
        quotes = quote_pattern.findall(text)
        for q in quotes:
            text = text.replace(q, quote_transformation(q))        
        return text