'''
Created on 29/10/2013

@author: David Vilares Calvo
'''
import os
import re
from miopia.classifier.WekaClassificationStrategy import WekaClassificationStrategy
from miopia.classifier.WekaClassificationStrategy import ClassifierWeka
from miopia.util.ConfigurationManager import ConfigurationManager


class MetaStrategy(WekaClassificationStrategy):
    '''
    classdocs
    '''
    ALLOWED_JAVA_HEAP_XMX = ConfigurationManager().getParameter("allowed_java_heap")
    
    def __init__(self, evaluator=None, search_method=None, 
                 classifier_weka=None, path_weka=None,
                 input_arff="/tmp/weka_classifier_input.arff",
                 results_file="/tmp/outputMeta.txt", model=None):
        '''
        Constructor
        @param classifier_weka: A element of L{ClassifierWekaPath} or an instance of L{miope.classifier.MetraStrategy}
        @param evaluator: An instance of L{miope.classifier.WekaClassificationStrategy.AttributeEvaluator}
        @param search_method: An instance of L{miope.classifier.WekaClassificationStrategy.SearchMethod}
        @param path_weka: A path to the weka.jar. None if weka is in your classpath
        @param model: A path to a trained model (SOMETHING.model). If None, a model must
        be trained using train() method.
        '''
        
        self._evaluator = evaluator
        self._search_method = search_method
        self._classifier = classifier_weka
        self._dict_information = {}
        if model is None: 
            self._meta_information = None
            classes = None
        else: 
            self._meta_information_file = model+"_meta_info"
            self.meta_information(self._meta_information_file)
            classes = self._dict_information['categories']
        super(MetaStrategy,self).__init__(classes, path_weka,input_arff,results_file,model)    


    def get_dict_information(self):
        return self._dict_information
    
    def get_evaluator(self):
        return self._evaluator
    
    def get_search_method(self):
        return self._search_method


    def get_base_classifier_configuration(self):
        if isinstance(self._classifier, MetaStrategy):
            return (
                    " -- -E "+"\""+str(self._classifier.get_evaluator())+"\""
                    +" -S "+"\""+str(self._classifier.get_search_method())+"\""
                    +" -W "+self._classifier.get_base_classifier_path()+" -- ")
        else:
            return ' '
        
    def get_base_classifier_path(self):
        if isinstance(self._classifier, MetaStrategy):
            return ClassifierWeka.META_CLASSIFIER
        else:
            return self._classifier 


    def _train_model(self,arff_training_file):
        
        self._meta_information = self._model+"_meta_info"

#        print("java -Xmx"+self.ALLOWED_JAVA_HEAP_XMX+" -cp "+self._path_weka+" "+ClassifierWeka.META_CLASSIFIER+" -no-cv -v"
#        +" -E "+"\""+str(self._evaluator)+"\""
#        +" -S "+"\""+str(self._search_method)+"\""
#        +" -W "
#        +self.get_base_classifier_path()
#        +" -t "+arff_training_file+" -d "+self._model
#        +self.get_base_classifier_configuration()
#        +" > "+ self._meta_information) 
        
        os.system("java -Xmx"+self.ALLOWED_JAVA_HEAP_XMX+" -cp "+self._path_weka+" "+ClassifierWeka.META_CLASSIFIER+" -no-cv -v"
        +" -E "+"\""+str(self._evaluator)+"\""
        +" -S "+"\""+str(self._search_method)+"\""
        +" -W "
        +self.get_base_classifier_path()
        +" -t "+arff_training_file+" -d "+self._model
        +self.get_base_classifier_configuration()
        +" > "+ self._meta_information) 

#weka.classifiers.meta.AttributeSelectedClassifier -E "weka.attributeSelection.InfoGainAttributeEval " -S "weka.attributeSelection.Ranker -T -1.7976931348623157E308 -N -1" -W weka.classifiers.meta.AttributeSelectedClassifier -- -E "weka.attributeSelection.PrincipalComponents -R 0.95 -A 5" -S "weka.attributeSelection.Ranker -T -1.7976931348623157E308 -N -1" -W weka.classifiers.functions.SMO 

    
    def meta_information(self,meta_information_file):
        meta_information_string = open(meta_information_file).read()
        print "Entra meta information"
        match_number_attributes = re.findall('Selected attributes:.*',meta_information_string)
        match_evaluator = re.findall('Attribute Evaluator.*\n.*\n',meta_information_string)
        match_search_method = re.findall('Search Method:.*\n.*\n',meta_information_string)
        match_categories = re.findall('@attribute class.*',meta_information_string)
        match_threshold_discarding_attributes = re.findall('Threshold for discarding attributes.*',meta_information_string)
        for meta_data in ['evaluator','search_method','search_method_threshold','number_attributes']:
            self._dict_information[meta_data] = []

     
        
        for match in match_categories:
            self._dict_information['categories'] = match.split()[2].replace('{','').replace('}','').split(',')
            self._classes = self._dict_information['categories']
        
        for match in match_evaluator:
            self._dict_information['evaluator'].append(match.split('\n')[1].replace('\t',''))
        for match in match_search_method:
            self._dict_information['search_method'].append(match.split('\n')[1].replace('\t',''))
        for match in match_threshold_discarding_attributes:
            self._dict_information['search_method_threshold'].append(float(match.split(":")[1]))
        for match in match_number_attributes:
            self._dict_information['number_attributes'].append(int(match.rsplit(':')[2]))
        print "Sale"
        return self._dict_information

    def _get_model_classifications(self):

        os.system("java -Xmx"+self.ALLOWED_JAVA_HEAP_XMX+" -cp "+self._path_weka+" "+ClassifierWeka.META_CLASSIFIER
        +" -classifications \"weka.classifiers.evaluation.output.prediction.PlainText " "-file "+self._results_file
        +" -decimals 15 -suppress \" "
        +" -l "+self._model+" -T "+self._input_arff)

        
        f = open(self._results_file,"r")
        lines = f.readlines()
        f.close()
        return lines[1:len(lines)-1]