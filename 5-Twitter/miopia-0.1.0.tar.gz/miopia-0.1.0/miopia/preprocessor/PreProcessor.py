#-*- coding: utf-8 -*-
'''
@author: David Vilares Calvo
'''
import codecs
import re
from miopia.util.ConfigurationManager import *

from time import time

class PreProcessor(object):
    '''
    Tools for preprocessing a plain text
    '''


    def __init__(self):
        '''
        Constructor
        '''
        self._composite_words = self._get_composite_words(ConfigurationManager().getParameter('path_composedwords'))
        self._abbreviations = self._get_abbreviations(ConfigurationManager().getParameter('path_abbreviations'))
        self._composite_words_patterns = self._get_composite_words_patterns(self._composite_words)
        self._abbreviations_patterns = self._get_abbreviations_patterns(self._abbreviations)
        self._special_abbreviations_patterns = self._get_special_abbreviations_patterns(self._abbreviations)
        
    def _get_composite_words(self,input_path):
        """
        Gets the composite words dictionary 
        @param input_path: A path to the composite words  dict file
        @precondition: Composite words dict must has this format: OriginalCompositeWord\tJoinedCompositeWord
        """
        words = codecs.open(input_path,encoding="utf-8").readlines()
        D = {}
        for word in words:
            columns = word.split('\t')
            if len(columns) == 2:
                if not D.has_key(columns[0]) and columns[0] != '':
                    D[columns[0]] = columns[1].replace('\n'.encode(),''.encode())
        return D
    
    
    def _get_composite_words_patterns(self,dict_composite_words):
        dict_composite_words_patterns = {}
        keys = self._composite_words.keys()
        for key in keys:
            pattern = re.compile('[ .,;:¡¿!?\[]+'.decode('utf-8')+key+'[ .,;:¡¿!?\]]+'.decode('utf-8')+'|'
                                +'[ .,;:¡¿!?\]]+'.decode('utf-8')+key+'$'+'|'
                                +'^'+key+'[ .,;:¡¿!?\]]+'.decode('utf-8')+'|'
                                +'\\b'+key+'\\b', re.IGNORECASE)
            dict_composite_words_patterns[key] = pattern
        return dict_composite_words_patterns
            
            
            
    def _get_abbreviations_patterns(self,dict_abbreviations):
        #TODO: Bug if the line is exactly an abbreviation
        dict_abbreviations_patterns = {}
        abbreviations = self._abbreviations.keys()
        for abbr in abbreviations:
            
            try:
                aux_abbr = abbr.replace('(','\(').replace(')','\)').replace('[','\[').replace(']','\]')
                pattern = re.compile('[ .,;:¡¿!?\[]+'.decode('utf-8')+aux_abbr+'[ .,;:¡¿!?\]]+'.decode('utf-8')+'|'
                                    +'[ .,;:¡¿!?\]]+'.decode('utf-8')+aux_abbr+'$'+'|'
                                    +'^'+aux_abbr+'[ .,;:¡¿!?\]]+'.decode('utf-8'), re.IGNORECASE)
                dict_abbreviations_patterns[abbr] = pattern
            except:
                pass
        return dict_abbreviations_patterns
        
        
    def _get_special_abbreviations_patterns(self,dict_abbreviations):
        dict_abbreviations_patterns = {}
        abbreviations = self._abbreviations.keys()
        for abbr in abbreviations:
            pattern = re.compile('[ .,;:¡¿!?\[]+'.decode('utf-8')+re.escape(abbr)+'[ .,;:¡¿!?\]]+'.decode('utf-8')+'|'
                                +'[ .,;:¡¿!?\]]+'.decode('utf-8')+re.escape(abbr)+'$'+'|'
                                 +'^'+re.escape(abbr)+'[ .,;:¡¿!?\]]+'.decode('utf-8'), re.IGNORECASE)
            dict_abbreviations_patterns[abbr] = pattern
        return dict_abbreviations_patterns
    
    
    def _get_abbreviations(self,input_path):
        """
        Gets the abbreviations dictionary
        @param input_path: A path to the abbreviations file
        @precondition: Abbreviations file must has this format: Abbreviation\tOriginalWord.
        """
        words = codecs.open(input_path,encoding="utf-8").readlines()
        D = {}
        for word in words:
            columns = word.split()
            if len(columns) == 2:
                if not D.has_key(columns[0]) and columns[0] != '':
                    D[columns[0]] = columns[1].replace('\n'.encode(),''.encode())
            else:
                if not D.has_key(columns[0]) and columns[0] != '':
                    D[columns[0]] = ''.encode()             
        return D
    
    
    
    def preprocess(self, text):
        """
        @param text: A string
        @return: A string preprocessed
        """
            
        tokens = []
        aux = text.split()
        #For each word
        for a in aux:
            tokens.append(self._format_punkt(a))
        return self._format_composite_words(self._format_abbreviations((' '.join(tokens)))) 



    def _format_punkt(self,token):
        """
        @param token: A token
        @return: A modified token with separated punkt, if is not a number, otherwise returns the token
        """
        lpunkt = [".",",",";",":","¡","¿"]
        if not self._is_number(token):
           
            #Deleting html quotes
#            for html_quote in ['&ldquo;','&rdquo;']:
#                token = token.replace(html_quote,'\"')
            token = token.replace('&ldquo;','\"').replace('&rdquo;','\"')

            if self._is_hour(token):
                return token.replace('h','').replace(':','.')
         
            if self._is_number(token.replace(",",".")):
                return token
            #Special quotes normalization
            #Decode is necessary because there are non ASCII  chars
            token = token.replace("“".decode('utf-8'),"\"").replace("”".decode('utf-8'),"\"")       
            #It is processed already well by the parser
            if "..." in token:
                return token
            else:
                for p in lpunkt:
                    if not token.endswith(p.decode("utf-8")):
                        token = token.replace(p.decode("utf-8"),p.decode("utf-8")+" ") 
                if '.' in token and not '.' == token:
                    token = token.replace("."," .")              
                return token       
        else:
            return token.replace(","," , ")
        


    def _format_composite_words(self,line):
        """
        @param line: A line of a sentence
        @return: A line where composite words are joined as one token
        """
        keys = self._composite_words.keys()
        keys_in_line = [key for key in keys if key in line]
        for key in keys_in_line:
            composed_expressions = self._composite_words_patterns[key].findall(line)
            for c in composed_expressions:
                line = line.replace(c,c.replace(key,self._composite_words.get(key)))
        return line

   

    def _format_upper_abbreviations(self,line,a,abbr): 
        #Is the abbreviation but with different capitalisation

        if abbr not in a:          
            return line.replace(a,a.lower()).replace(a.lower(),a.lower().replace(abbr,self._abbreviations.get(abbr)))
        else:
            return line.replace(a,a.replace(abbr,self._abbreviations.get(abbr)))        
    
    
    def _format_abbreviations(self,line):

        abbreviations = self._abbreviations.keys()
        abbreviations_in_line = [abbr for abbr in abbreviations if abbr in line]
        
        for abbr in abbreviations_in_line:
            try:
                abbreviations_found = set(self._abbreviations_patterns[abbr].findall(line))
            except  KeyError:
                abbreviations_found = set(self._special_abbreviations_patterns[abbr].findall(line))
            for abbreviation_found in abbreviations_found:
                line = self._format_upper_abbreviations(line,abbreviation_found,
                                                        abbr)
        return line
    
    
    def _is_number(self, token):
        """
        @param token: A token
        @return: True if is a number, False otherwise
        """
        try:
            #Por si un numero aparece pegado a algun simbolo como una coma o un punto y coma
            if token.endswith(',') or token.endswith(';'):
                posible_number = token[0:len(token)-1]
            else:
                posible_number = token    
            float(posible_number)
            #Float es capaz de transformas numeros acabados en .
            #Si es asi devolvemos Falso, para que luego se parsee correctamente como dos simbolos
            #el numero y el signo
            return not posible_number.endswith('.')
        except ValueError:
            False
            
    def _is_hour(self,token):
        return re.match('[0-9]+:[0-9]+[h]{0,1}|[0-9]+.[0-9]+[h]{1}',token) is not None
        
        
        
            
            
        