'''
Created on 11/04/2013

@author: David Vilares
'''

from miopia.adapter.Feature import FeatureType
from miopia.adapter.Feature import FeatureTypeConfiguration
from miopia.adapter.Feature import FeatureWekaDataType
from miopia.adapter.Feature import FeatureLevelBackOff
from miopia.adapter.Feature import Feature
from miopia.adapter.Feature import SentimentFeature
from miopia.analyzer.Analyzer import Analyzer
from miopia.analyzer.AnalyzerConfiguration import AnalyzerConfiguration
from miopia.analyzer.LinguisticInfo import LinguisticInfo
from miopia.analyzer.SentimentAnalyzer import SentimentAnalyzer
import codecs
import itertools
import time

class LinguisticAnalyzer(Analyzer):
    '''
    """
    Instances of L{LinguisticAnalyzer} evaluates 
    L{SentimentDependencyGraph}'s of a text, returning a summary of the extracted
    features in a L{LinguisticInfo} object
    """
    '''
    #ROOT_WORD = "ROOT_WORD"

    def __init__(self, parser, dictionaries,
                 dictionary_adapted_features,
                 preprocessor=None, lexical_processor=None):
        '''
        Constructor
        '''

        aconf= AnalyzerConfiguration(final_sentences_weight=1, caps_int=0., 
                                     replication_int=0., restrictive_adv_weight=0.75,
                                     restrictive_main_weight=1.4, without_shift = 3.5,
                                     neg_shift=4)
        self._sentiment_analyzer = SentimentAnalyzer(parser,dictionaries,aconf,
                                                     preprocessor,
                                                     lexical_processor)
        
        self._dictionary_adapted_features = dictionary_adapted_features
        self._switch_type_back_off = {FeatureLevelBackOff.TYPE_BACK_OFF_COARSE_TAG: self._ctag,
                                FeatureLevelBackOff.TYPE_BACK_OFF_FINE_TAG: self._tag,
                                FeatureLevelBackOff.TYPE_BACK_OFF_LEMMA: self._lemma,
                                FeatureLevelBackOff.TYPE_BACK_OFF_POLARITY_WORDS: self._get_polarity_info,
                                FeatureLevelBackOff.TYPE_BACK_OFF_SEMANTIC_ORIENTATION: self._get_polarity_info,
                                FeatureLevelBackOff.TYPE_BACK_OFF_WORD: self._word,
                                FeatureLevelBackOff.TYPE_BACK_OFF_PSYCHOMETRIC: self._psychometric_properties,
                                FeatureLevelBackOff.TYPE_BACK_OFF_EMPTY: self._empty}
        
        super(LinguisticAnalyzer,self).__init__(parser,dictionaries,preprocessor,lexical_processor)

        
    def get_dictionary_adapted_features(self):
        """
        Obtains the features considered by the L{LinguisticAnalyzer}
        @return: A dictionary. The key is a tuple (L{FeatureType}, L{FeatureTypeConfiguration}). Value is a list of strings which
        represents the names of the features.
        """
        return self._dictionary_adapted_features

    def _empty(self,**kwargs):
        return ''

    def _ctag(self,**kwargs):
        node = kwargs['node']
        dg = kwargs['dependency_graph']
        return dg.get_ctag(node)
    
    def _tag(self,**kwargs):
        node = kwargs['node']
        dg = kwargs['dependency_graph']
        return dg.get_tag(node)

    def _word(self,**kwargs):
        node = kwargs['node']
        dg = kwargs['dependency_graph']
        return dg.get_word(node).replace('\'','').replace(FeatureTypeConfiguration.DELIMITER_CONFIGURATION,'').replace('\\','')
        
    def _lemma(self,**kwargs):  
        s_node = kwargs['node']
        dg = kwargs['dependency_graph']
        return self._dictionaries.get_lemma(dg.get_lexical_category(s_node),self._word(node=s_node,
                                                                                       dependency_graph=dg)).lower()

    def _psychometric_properties(self,**kwargs):
        s_node = kwargs['node']
        dg = kwargs['dependency_graph']
        return self._dictionaries.get_psychometric_categories(self._word(node= s_node,
                                                                         dependency_graph = dg))        

    def _get_polarity_info(self,**kwargs):
            node = kwargs['node']
            dg = kwargs['dependency_graph']
            ftp_type_back_off = kwargs['type_back_off']
            try:   
                lexical_category = dg._get_lexical_category(node)
                semantic_category = self.get_semantic_category(dg, node)
                word = dg.get_word(node)
                lemma = self._dictionaries.get_lemma(lexical_category,word)
                so = str(self._dictionaries.get_semantic_orientation(lemma, semantic_category))
            except:
                lemma = dg.get_ctag(node)
                so = 0.        
            finally:
                if ftp_type_back_off == FeatureLevelBackOff.TYPE_BACK_OFF_POLARITY_WORDS:
                    return lemma
                else:
                    return so                       



    def _get_node_back_off_values(self,dg, selected_node, 
                                  ftp_type_back_off):
        """
        @param dg: A L{SentimentDependencyGraph} 
        @param selected_node: A node of a the dg
        @param ftp: A Type of class L{FeatureTypeConfiguration}
        """

        return self._switch_type_back_off[ftp_type_back_off](dependency_graph=dg,
                                                             node =selected_node,
                                                             type_back_off = ftp_type_back_off)
            

    def _analyze_graphs(self, dependency_graphs):
        """
        @param dependency_graphs: A list of DependencyGraphs
        @return: A tuple ([L{SentimentDependencyGraph}],L{LinguisticInfo})
        """
        ini = time.time()
        list_features = []
        switch = {FeatureType.CROSS_POSTAG: self.count_cross_postags,
                  FeatureType.FINE_POSTAG: self.count_fine_postags,
                  FeatureType.DEPENDENCY: self.count_dependency_types,
                  FeatureType.DEPENDENCY_TRIPLET: self.count_dependency_triplets,
                  FeatureType.PSYCHOMETRIC: self.count_psychometrics,
                  FeatureType.GRAM: self.count_ngram,
                  FeatureType.SENTIMENT_FEATURE: self.count_sentiment}
        
        dict_features = {}
        for feature_type, ftc in self._dictionary_adapted_features.keys():
            dict_features[feature_type, ftc] = {}
         
            for dg in dependency_graphs:
                dict_aux = switch[feature_type](dg,0,ftc) 
                dict_features[feature_type,ftc] = dict((n, dict_features[feature_type, ftc].get(n,0)+dict_aux.get(n,0)) 
                                                    for n in set(dict_features[feature_type,ftc])| set(dict_aux)) 
       
        for feature_type, ftc in self._dictionary_adapted_features.keys():
            set_features_appeared_in_graph = set(dict_features[feature_type,ftc]).intersection(self._dictionary_adapted_features[feature_type,ftc])
            for feature_appeared in set_features_appeared_in_graph:
                list_features.append(Feature(feature_appeared,
                                         dict_features[feature_type,ftc].get(feature_appeared),
                                         feature_type,
                                         ftc,
                                         FeatureWekaDataType.NUMERIC
                                         ))

        return dependency_graphs,LinguisticInfo(list_features) 


    def analyze(self,text):
        """
        @param text: A string. Use unicode 
        @return: A tuple ([L{SentimentDependencyGraph}],L{LinguisticInfo})
        """
        tagged_sentences, lsi = self._preanalyze(text)
        dependency_graphs = self._parser.parse(tagged_sentences)   
        return self._analyze_graphs(dependency_graphs)  


    def analyze_from_conll(self, file_path,**kwargs):
        """
        Extracts features from a text given a parsed file
        @param file_path: A path to the input CoNLL 2006 file
        @param lsi: A instance of L{LexicalSentimentInfo} with sentiment information of the file.
        @return: A tuple ([L{SentimentDependencyGraph}],L{LinguisticInfo})
        """    
        dependency_graphs = self._parser.parse_from_conll(file_path)
        return self._analyze_graphs(dependency_graphs)
                                    

    def analyze_from_plain_file(self, file_path,input_encoding='utf-8'):
        """
        Extracts features for a given text
        @param file_path: A path to the input plain file
        @param input_encoding: Encoding of text
        @param list_features_types: A list of L{FeatureType}
        @return: A tuple ([L{SentimentDependencyGraph}],L{LinguisticInfo})
        """        
        f = codecs.open(file_path,encoding=input_encoding)
        text = f.read()
        ptext = self._preprocessor.preprocess(text)
        sentences =self._lexical_processor.extract_sentences(ptext)
        (tokens,lsi) = self._lexical_processor.extract_tokens(sentences)
        tagged_sentences = self._lexical_processor.extract_tags(tokens)
        
        dependency_graphs = self._parser.parse(tagged_sentences)   
        f.close()
        return self._analyze_graphs(dependency_graphs)        
        
        
    def count_cross_postags(self, dependency_graph, address, feature_type_configuration):
        """
        @param dependency_graph: A L{SentimentDependencyGraph}
        @param address: A valid identifier of a node of the graph
        @param feature_type_configuration: A L{FeatureTypeConfiguration} indicating the
        specific configuration for this type of feature
        @return: A dictionary {Coarse Pos-tag: Number of occurrences}. 
        """
        node = dependency_graph.get_by_address(address)   
        if dependency_graph.is_leaf(node):
            return ({dependency_graph.get_ctag(node):1.})
        else:
            dict_pos= {dependency_graph.get_ctag(node):1.}   
            children = dependency_graph.get_deps(node)
            for child in children:
                dict_child = self.count_cross_postags(dependency_graph, child, feature_type_configuration) 
                dict_pos = dict((n, dict_pos.get(n,0)+dict_child.get(n,0)) for n in set(dict_pos)| set(dict_child)) 
            return (dict_pos)
        
        
    def count_fine_postags(self, dependency_graph, address, feature_type_configuration):
        """
        @param dependency_graph: A L{SentimentDependencyGraph}
        @param address: A valid identifier of a node of the graph
        @param feature_type_configuration: A L{FeatureTypeConfiguration} indicating the
        specific configuration for this type of feature
        @return: A dictionary {Fine Pos-tag: Number of occurrences}. 
        """
        node = dependency_graph.get_by_address(address)   
        if dependency_graph.is_leaf(node):
            return ({dependency_graph.get_tag(node):1.})
        else:
            dict_pos= {dependency_graph.get_tag(node):1.}    
            children = dependency_graph.get_deps(node)
            for child in children:
                dict_child = self.count_fine_postags(dependency_graph, child, feature_type_configuration) 
                dict_pos = dict((n, dict_pos.get(n,0)+dict_child.get(n,0)) for n in set(dict_pos)| set(dict_child)) 
            return (dict_pos)
        
        
    def count_dependency_types(self, dependency_graph, address, feature_type_configuration):
        """
        @param dependency_graph: A L{SentimentDependencyGraph}
        @param address: A valid identifier of a node of the graph
        @param feature_type_configuration: A L{FeatureTypeConfiguration} indicating the
        specific configuration for this type of feature
        @return: A dictionary {Dependency type: Number of occurrences}. 
        """
        node = dependency_graph.get_by_address(address)   
        if dependency_graph.is_leaf(node):
            return ({dependency_graph.get_rel(node):1.})
        else:
            dict_dep = {dependency_graph.get_rel(node):1.}      
            children = dependency_graph.get_deps(node)
            for child in children:
                dict_child = self.count_dependency_types(dependency_graph, child, feature_type_configuration) 
                dict_dep = dict((n, dict_dep.get(n,0)+dict_child.get(n,0)) for n in set(dict_dep)| set(dict_child))  
            return (dict_dep)
      
                


    def count_dependency_triplets(self,dg ,address, ftp):
        """
        @param dependency_graph: A L{SentimentDependencyGraph}
        @param address: A valid identifier of a node of the graph
        @param feature_type_configuration: A L{FeatureTypeConfiguration} indicating the
        specific configuration for this type of feature
        @return: A dictionary {head-dp-dependent: Number of occurrences}. 
        """        
        node = dg.get_by_address(address)   
        if dg.is_leaf(node):
            return ({})
        else:     
            dict_dep = {}
            children = dg.get_deps(node)
            for child in children:
                child_node = dg.get_by_address(child)
                head_value = self._get_node_back_off_values(dg, node, ftp.get_back_off_head())
                dependent_value = self._get_node_back_off_values(dg, child_node, ftp.get_back_off_dependent())

                if type(head_value) != type([]):
                    head_value = [head_value]             
                if type(dependent_value) != type([]):
                    dependent_value = [dependent_value]
                
                list_pairs_head_dependent = itertools.product(head_value, 
                                                              dependent_value)
                for pair in list_pairs_head_dependent:
                    if ftp.get_add_dependency_type() is True:
                        dependency_triplet = pair[0]+"-"+dg.get_rel(child_node)+"-"+pair[1]
                    else:
                        dependency_triplet = pair[0]+"-"+pair[1]   
                    if dict_dep.has_key(dependency_triplet):
                        dict_dep[dependency_triplet] += 1.
                    else:
                        dict_dep[dependency_triplet] = 1. 
                    
                dict_child = self.count_dependency_triplets(dg, child, ftp) 
                dict_dep = dict((n, dict_dep.get(n,0)+dict_child.get(n,0)) for n in set(dict_dep)| set(dict_child))  
            return (dict_dep)   



    def count_sentiment(self,dg,address,ftp):
        """
        @param dependency_graph: A L{SentimentDependencyGraph}
        @param address: A valid identifier of a node of the graph
        @param ftp: A L{FeatureTypeConfiguration} indicating the
        specific configuration for this type of feature
        @return: A dictionary {L{SentimentInfo} attribute: Estimated value}. 
        """        
        
        sentiment_info = self._sentiment_analyzer.evaluate(dg,dg.get_by_address(address))
        dict_sentiment = {}
        
        dict_sentiment[SentimentFeature.SUBJECTIVITY] = sentiment_info.get_subjectivity()
        dict_sentiment[SentimentFeature.SEMANTIC_ORIENTATION] = sentiment_info.get_so()
        dict_sentiment[SentimentFeature.POS_WORDS] = sentiment_info.get_pos_words()
        dict_sentiment[SentimentFeature.NEG_WORDS] = sentiment_info.get_neg_words()
        dict_sentiment[SentimentFeature.NUMBER_INTENSIFIERS] = sentiment_info.get_number_intensifiers()
        dict_sentiment[SentimentFeature.LENGTH_TEXT] = sentiment_info.get_length_text()
        dict_sentiment[SentimentFeature.NUMBER_WORDS] = sentiment_info.get_number_words()

        return dict_sentiment


    def _count_uni_gram(self, dependency_graph, address, feature_type_configuration):
        """
        @param dependency_graph: A L{SentimentDependencyGraph}
        @param address: A valid identifier of a node of the graph
        @param feature_type_configuration: A L{FeatureTypeConfiguration} indicating the
        specific configuration for this type of feature
        @return: A dictionary {Uni-gram: Number of occurrences}. 
        """        
        
        node = dependency_graph.get_by_address(address)   
             
        if dependency_graph.is_leaf(node):
            if dependency_graph.is_root_node(node):
                return {}
            return ({self._get_node_back_off_values(dependency_graph,node, feature_type_configuration.get_n_gram_back_off()):1.})
        else:
            if dependency_graph.is_root_node(node):
                dict_dep = {}
            else: dict_dep = {self._get_node_back_off_values(dependency_graph,node, feature_type_configuration.get_n_gram_back_off()):1.}      
            children = dependency_graph.get_deps(node)
            for child in children:
                dict_child = self._count_uni_gram(dependency_graph, child, feature_type_configuration) 
                dict_dep = dict((n, dict_dep.get(n,0)+dict_child.get(n,0)) for n in set(dict_dep)| set(dict_child))  
            return (dict_dep)
        
        
    def count_ngram(self,dependency_graph,address, feature_type_configuration):
        """
        @param dependency_graph: A L{SentimentDependencyGraph}
        @param address: A valid identifier of a node of the graph
        @param feature_type_configuration: A L{FeatureTypeConfiguration} indicating the
        specific configuration for this type of feature
        @return: A dictionary {N-gram: Number of occurrences}. 
        """                
        def dependency_graph_to_sentence(dependency_graph,address):
            node = dependency_graph.get_by_address(address)
            if dependency_graph.is_leaf(node):
                if dependency_graph.is_root_node(node): return [node]
                return [node]
            else:
                if dependency_graph.is_root_node(node): raw_nodes = [node]
                else: raw_nodes = [node]
                children = dependency_graph.get_deps(node)
                for child in children:
                    raw_nodes.extend(dependency_graph_to_sentence(dependency_graph,child))
                return raw_nodes
        
        
        def build_n_gram(node,sorted_list_nodes):
            index_begin = int(dependency_graph.get_address(node))
            n = int(feature_type_configuration.get_n_gram())
            index_end = index_begin + n
            if index_end > len(sorted_list_nodes):
                return None
            else:
                n_gram = '_'.join([self._get_node_back_off_values(dependency_graph,node, feature_type_configuration.get_n_gram_back_off())
                        for node in sorted_list_nodes[index_begin:index_end]])
                if self._word_contain_invalid_token(n_gram):
                    return None
                else:
                    return n_gram 
        
        if int(feature_type_configuration.get_n_gram()) == 1:
            return self._count_uni_gram(dependency_graph, address, feature_type_configuration)

        ini = time.time()        
        list_nodes = sorted(dependency_graph_to_sentence(dependency_graph,address), 
                            key=lambda k: k['address'])
        if feature_type_configuration.get_n_gram_back_off() in [FeatureLevelBackOff.TYPE_BACK_OFF_LEMMA,
                                                            FeatureLevelBackOff.TYPE_BACK_OFF_WORD]:
            list_n_gram = [build_n_gram(node,list_nodes)
                       for node in list_nodes 
                       if (not dependency_graph.is_root_node(node) and 
                           not self._contain_invalid_token(node)
                           and build_n_gram(node,list_nodes) != None)]
        
        else:
            
            list_n_gram = [build_n_gram(node,list_nodes)
                       for node in list_nodes 
                      # if (not self.is_root_node(node) and 
                       if (not self._contain_invalid_token(node)
                          and build_n_gram(node,list_nodes) != None )]
        dict_n_gram = {n_gram: float(list_n_gram.count(n_gram)) 
                       for n_gram in set(list_n_gram)}

        return dict_n_gram


    def count_psychometrics(self,dependency_graph,address, feature_type_configuration):
        """
        @param dependency_graph: A L{SentimentDependencyGraph}
        @param address: A valid identifier of a node of the graph
        @param feature_type_configuration: A L{FeatureTypeConfiguration} indicating the
        specific configuration for this type of feature
        @return: A dictionary {Psychological property: Number of occurrences}. 
        """        
        node = dependency_graph.get_by_address(address)   
        if dependency_graph.is_leaf(node):
            return {category:1. 
                    for category in self._dictionaries.get_psychometric_categories(dependency_graph.get_word(node))} 
        else:    
            dict_psychometric_categories = {category:1. 
                                            for category in self._dictionaries.get_psychometric_categories(dependency_graph.get_word(node))}  
            children = dependency_graph.get_deps(node)
            for child in children:
                dict_child = self.count_psychometrics(dependency_graph, child, feature_type_configuration) 
                dict_psychometric_categories = dict((n, dict_psychometric_categories.get(n,0)+dict_child.get(n,0)) 
                                                    for n in set(dict_psychometric_categories)| set(dict_child))  
            return (dict_psychometric_categories)
        
        
        
        