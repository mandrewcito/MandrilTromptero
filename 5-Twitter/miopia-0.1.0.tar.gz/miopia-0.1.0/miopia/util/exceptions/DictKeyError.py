'''
@author: David Vilares Calvo
'''

class DictKeyError(Exception):
    pass
        