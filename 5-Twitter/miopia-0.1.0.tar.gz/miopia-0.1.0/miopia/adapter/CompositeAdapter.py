'''
Created on 28/05/2013

@author: David Vilares Calvo
'''

from miopia.parser.Parser import Parser
from miopia.adapter.Adapter import Adapter
from collections import defaultdict
import os


class CompositeAdapter(Adapter):
    '''
    CompositeAdapter allows to combine different L{src.miope.adapter.Adapter}'s to obtain a global ranking
    off all features
    '''
    FEATURE_TYPE = "COMPOSITE_FEATURE_TYPE"

    def __init__(self,float_threshold,path_weka,arff_file="/tmp/CompositeAdapter.arff"):
        '''
        @param float_threshold: An information gain threshold (minimum) for selecting features
        @param path_weka: A path to the weka jar
        @param arff_file: A path to the destination arff file
        '''
        self._parser = Parser()
        self._list_adapters = []
        self._list_external_resources = []
        super(CompositeAdapter,self).__init__(float_threshold,None,path_weka,arff_file)
        
    
    def add(self,adapter):
        """
        Add an L{Adapter} to the composite adapter
        """
        self._list_adapters.append(adapter)
    
    def remove(self,adapter):
        """
        Remove and L{Adapter} from the composite adapter 
        """
        self._list_adapters.remove(adapter)
        
    def get_children(self):
        """
        Obtain the children of a L{CompositeAdapter}
        """
        return self._list_adapters
    
    def _get_feature_type(self):
        return self.FEATURE_TYPE
    
    
    def _analyze_graph(self,dg):
        dict_features = {}
        for adapter in self._list_adapters:
            dict_features.update(adapter._analyze_graph(dg))
        return dict_features


    def count_features(self,dg):
        """
        @return A dictionary with the number of features considered by the adapter in an instance
        of a L{nltk.parse.dependencygraph.DependencyGraph} 
        """
        dict_features = {}
        for adapter in self._list_adapters:
            dict_features.update(adapter.count_features(dg))
        return dict_features


    def _to_arff(self, training_dir):
        """
        @param training_dir: The training directory. Files must be in CoNLL-2006 format. 
        The directory mus be structured as follows:
        Category1:
            file1.1
            ...
            file1.n
        ....
        Categoryn:
            filen.1
            ....
            filen.m 
        """
        file_id = 0
        set_features = set([])
        dict_info_features = {}
        dict_features_file = defaultdict(defaultdict)
        dict_category_file = {}
        categories = os.listdir(training_dir)
        for c in categories:
            files_c = os.listdir(training_dir+"/"+c)
            for f in files_c:
                dict_category_file[file_id] = c              
                dependency_graphs = self._parser.parse_from_conll(training_dir+"/"+c+"/"+f)
                dict_composite_features = {}
                for dg in dependency_graphs:
                    for adapter in self._list_adapters:
                        dict_composite_features.update(adapter.count_features(dg))
                    for feature in dict_composite_features:
                        feature_type, configuration, name =  self._get_feature_configuration(feature)
                        if feature not in set_features:
                            try:
                                dict_info_features[feature_type, configuration].append(name)
                            except:
                                dict_info_features[feature_type, configuration] = [name]
                            set_features.add(feature)
                        try:
                            dict_features_file[file_id][feature]+=dict_composite_features[feature] 
                        except:
                            dict_features_file[file_id][feature] = dict_composite_features[feature]

                file_id+=1    

        self._to_arff_data(dict_info_features, dict_features_file, dict_category_file, categories, file_id)


  

    
#     
#     def _get_features(self,ranking_file):   
#         """
#         @param ranking_file:  A path to an existing ranking file
#         @precondition: ranking_file must be in the format provided by the WEKA selection attribute tools
#         @return A dictionary of features given a ranking file provided by WEKA attribute selection tools
#         """
# 
#         dict_features = {}
# 
# 
#         lines_aux = codecs.open(ranking_file,"r",'utf-8').read().split(
#                         'Selected attributes:')[0].split('\n')
# 
#         lines_attributes = lines_aux[11:len(lines_aux)-2]
#         for l in lines_attributes:
#             l_splitted = l.split()
#             information_gain,_,key_atr = float(l_splitted[0]), l_splitted[1], l_splitted[2]  
#             #We only select attributes with a positive information gain        
#             if information_gain > self._threshold:
#                 feature_type, ftc, name = self._get_feature_configuration(key_atr) 
#                 
#                 try: 
#                     dict_features[feature_type, ftc].append(name) 
#                 except KeyError:
#                     dict_features[feature_type, ftc] = [name]   
#         return dict_features
    