'''
Created on 29/01/2013

@author: David Vilares
'''

class ClassifierI(object):
    '''
    classdocs
    '''

    def __init__(self):
        '''
        Constructor
        '''
        raise NotImplementedError
    
    def classify(self,list_path_files):
        raise NotImplementedError
    
    def classify_from_info(self,info,**kwargs):    
        return NotImplementedError
        
        