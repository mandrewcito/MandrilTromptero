'''
Created on 09/10/2013

@author: David Vilares
'''

from miopia.adapter.NLPAdapter import NLPAdapter
from miopia.adapter.Feature import FeatureType
from miopia.util.exceptions.FeatureTypeConfigurationException import FeatureTypeConfigurationException

class SentimentAdapter(NLPAdapter):
    '''
    SentimentAdapter allows to obtain sentiment features from L{src.miope.analyzer.SentimentAnalyzer} 
    to then train a L{src.miope.classifier.ClassifierI}
    '''


    def __init__(self,float_threshold, feature_type_configuration,
                 list_desired_sentiment_features,
                 path_weka, arff_file='/tmp/SentimentAdapter.arff'):
        '''
        @param fine_tag: A boolean indicating if the adapter must obtain coarse or fine tags.
        @param float_threshold: An information gain threshold (minimum) for selecting features
        @param feature_type_configuration: An instance of L{src.miope.adapter.Feature.FeatureTypeConfiguration}
        @param path_weka: A path to the weka.jar
        @param arff_file: A path to the destination arff file
        @precondition: L{src.miope.adapter.Feature.FeatureTypeConfiguration} n_gram,
        add_dependency_type, back_off_head, back_off_dependent and n_gram_back_off attributes must be None
        '''
        if (feature_type_configuration.get_n_gram() != None
            or feature_type_configuration.get_n_gram_back_off() != None
            or feature_type_configuration.get_add_dependency_type() != None
            or feature_type_configuration.get_back_off_head() != None
            or feature_type_configuration.get_back_off_dependent() != None):
                raise FeatureTypeConfigurationException(str(SentimentAdapter)+': parameters not applicable')
        self._list_desired_sentiment_features = list_desired_sentiment_features
        super(SentimentAdapter,self).__init__(float_threshold,
                                              feature_type_configuration,
                                              path_weka,arff_file)
        
    
    def _get_feature_type(self):
        """
        @return: A string with the feature type provided by the SentimentAdapter 
        """
        return FeatureType.SENTIMENT_FEATURE
    
    
    def _analyze_graph(self,dg):
        """
        @param dg: A L{SentimentDependencyGraph} instance
        """
        dict_features = self._linguistic_analyzer.count_sentiment(dg,0.,self._feature_type_configuration) 
        dict_desired_features = {key:dict_features[key] for key in dict_features.keys() 
                                 if key in self._list_desired_sentiment_features}
        return dict_desired_features
