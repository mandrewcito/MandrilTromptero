'''
Created on 11/04/2013

@author: David Vilares Calvo
'''

from miopia.adapter.Feature import FeatureType
from miopia.adapter.NLPAdapter import NLPAdapter
from miopia.util.exceptions.FeatureTypeConfigurationException import FeatureTypeConfigurationException

class DependencyTripletsAdapter(NLPAdapter):
    '''
    DependencyTripletsAdapter allows to obtain dependency triplets features to the train
    a L{ClassifierI}
    '''

    def __init__(self,float_threshold,
                 feature_type_configuration,
                 path_weka, arff_file='/tmp/DependencyTripletsAdapter.arff'):
        '''
        @param float_threshold: An information gain threshold (minimum) for selecting features
        @param feature_type_configuration: An instance of L{src.miope.adapter.Feature.FeatureTypeConfiguration}
        @param path_weka: A path to the weka jar
        @param arff_file: A path to the destination arff file
        @precondition: L{src.miope.adapter.Feature.FeatureTypeConfiguration} n_gram attribute must be None
        '''
        if (feature_type_configuration.get_n_gram() != None):
            raise FeatureTypeConfigurationException(str(DependencyTripletsAdapter)+': parameters not applicable')
        super(DependencyTripletsAdapter,self).__init__(float_threshold,
                                                       feature_type_configuration,
                                                       path_weka,arff_file)
        

    def _get_feature_type(self):
        """
        The type of the feature
        """
        return FeatureType.DEPENDENCY_TRIPLET
    
    def _analyze_graph(self,dg):
        """
        @param dg: An instance of L{SentimentDependencyGraph}
        @return A dictionary with the number of features considered by the adapter in an instance
        of a L{SentimentDependencyGraph} 
        """
        return self._linguistic_analyzer.count_dependency_triplets(dg, 0,
                                                                   self.get_feature_type_configuration())
        
