'''
Created on 25/02/2013

@author: David Vilares
'''
import time
import os
from miopia.classifier.WekaClassificationStrategy import WekaClassificationStrategy


class SMOStrategy(WekaClassificationStrategy):
    '''
    classdocs
    '''
    
    def __init__(self,classes, path_weka=None,
                 input_arff="/tmp/weka_classifier_input.arff",
                 results_file="/tmp/outputSMO.txt", model=None):
        '''
        Constructor
        @param classes: A list of L{PolarityType}. Each element represents a class. No duplicates
        @param path_weka: A path to the weka.jar. None if weka is in your classpath
        @param model: A path to a trained model (not xml). If None, a model must
        be trained using train() method.
        '''
        super(SMOStrategy,self).__init__(classes, path_weka,input_arff,results_file,model)
        
    
    
    def _train_model(self,arff_training_file):
        #-K \"weka.classifiers.functions.supportVector.PolyKernel -L\" #-no-cv no cross validation -v -i -o -r  
        os.system("java -cp "+self._path_weka+" weka.classifiers.functions.SMO -no-cv -v -i -o -r -t " 
        +arff_training_file+" -d "+self._model) 
    
    
    
    def _get_model_classifications(self):
        
        #weka.classifiers.functions.SMO -C 1.0 -L 0.001 -P 1.0E-12 -N 0 -V -1 -W 1 -K "weka.classifiers.functions.supportVector.PolyKernel -C 250007 -E 1.0"
        
        #-K \"weka.classifiers.functions.supportVector.PolyKernel " "-E 2.0 \"  
        os.system("java -cp "+self._path_weka+" weka.classifiers.functions.SMO "+
        " -classifications \"weka.classifiers.evaluation.output.prediction.PlainText " "-file "+self._results_file+" -decimals 15 -suppress \" "+ 
        " -l "+self._model+" -T "+self._input_arff)
        
        f = open(self._results_file,"r")
        lines = f.readlines()
        f.close()
        return lines[1:len(lines)-1]
    