'''
Created on 25/09/2013

@author: David Vilares
'''


from miopia.adapter.Feature import FeatureType
from miopia.adapter.NLPAdapter import NLPAdapter
from miopia.analyzer.Dictionary import Dictionary
from miopia.util.exceptions.FeatureTypeConfigurationException import FeatureTypeConfigurationException

class NGramAdapter(NLPAdapter):
    '''
    NGramAdapter allows to obtain ngram features to then train a L{ClassifierI}
    '''


    def __init__(self,float_threshold,feature_type_configuration,
                 path_weka,arff_file='/tmp/NGramAdapter.arff'):
        """
        @param float_threshold: An information gain threshold (minimum) for selecting features
        @param feature_type_configuration: An instance of L{FeatureTypeConfiguration}
        @param path_weka: A path to the weka jar
        @param arff_file: A path to the destination arff file
        @precondition: L{FeatureTypeConfiguration} add_dependency_type,
        back_off_head and back_off_dependent attributes must be None. However, you must specify a value
        for n_gram and n_gram_back_off attributes.
        """
        if (feature_type_configuration.get_add_dependency_type() != None
            or feature_type_configuration.get_back_off_head() != None
            or feature_type_configuration.get_back_off_dependent() != None):
            raise FeatureTypeConfigurationException(str(NGramAdapter)+': Parameters not applicable')
        if (feature_type_configuration.get_n_gram_back_off() == None):
            raise FeatureTypeConfigurationException(str(NGramAdapter)+': Specify n_gram_back_off')
        if feature_type_configuration.get_n_gram() == None:
            raise FeatureTypeConfigurationException(str(NGramAdapter)+': Specify n_gram size')
        
        self._n = feature_type_configuration.get_n_gram()
        self._dictionary = Dictionary()
        super(NGramAdapter,self).__init__(float_threshold,
                                          feature_type_configuration,
                                          path_weka,arff_file)
        
    
    def _get_feature_type(self):
        """
        The type of the feature
        """
        return FeatureType.GRAM
    
    def _analyze_graph(self,dg):
        """
        @param dg: An instance of L{SentimentDependencyGraph}
        @return A dictionary with the number of features considered by the adapter in an instance
        of a L{SentimentDependencyGraph} 
        """
        return self._linguistic_analyzer.count_ngram(dg, 0,
                                                     self.get_feature_type_configuration())
        