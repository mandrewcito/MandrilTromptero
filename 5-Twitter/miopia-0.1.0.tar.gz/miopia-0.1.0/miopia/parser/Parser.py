#-*- coding: utf-8 -*-
'''
@author: David Vilares Calvo
'''

import os
import codecs
from miopia.util.ConfigurationManager import ConfigurationManager
from miopia.parser.SentimentDependencyGraph import SentimentDependencyGraph
from miopia.preparator.TextPreparator import TextPreparator
from miopia.parser.TokenDependencyInfo import TokenDependencyInfo

class Parser(object):
    
    """
    Tools for interacting with MaltParser 1.7* and obtaining L{SentimentDependencyGraph}
    """
    def __init__(self):
        """
        Constructor
        """
        self._preparator = TextPreparator()
        
        

    def parse_from_conll(self,file_path):
        """
        @param file_path: A path to a CoNLL 2006 file parsed
        @return: A list of L{SentimentDependencyGraph} of file_path.
        """    
        #TODO: Better simplify in parse_to_file, not here
        sentences = self._simplify(file_path)    
        return [SentimentDependencyGraph(s) for s in sentences]
 
    
    
    def parse_dir_to_file(self,dir_path, list_of_tagged_sentences, 
                          input_path="/tmp/parse_dir_to_file_unparsed.conll",
                          output_path="/tmp/parse_dir_to_file_parsed.conll"):
        """
        It parses a whole directory of plain texts into a single file
        @param dir_path: The directory where the files and the sentencess stored
        in list_of_tagged_sentences will be written in CoNLL-2006 format.
        @param aux_path: The path to the file where all plain sentences will be written
        in CoNLL 2006 format before parsing them
        @param list_of_tagged_sentences: A list of (text_id,[[(token,L{INfoTag})]].
        """
        list_id_and_number_of_sentences = [] #ID: number of sentences of the file (int) 
        dir_tagged_sentences =[]
        for text_id, tagged_sentences in list_of_tagged_sentences:
            #print text_id, len(tagged_sentences)
            
            if tagged_sentences == [[]]:
                list_id_and_number_of_sentences.append((text_id,0))
            else:
                list_id_and_number_of_sentences.append((text_id,len(tagged_sentences))) 
            dir_tagged_sentences.extend(tagged_sentences)
        self.parse_to_file(output_path, dir_tagged_sentences,
                           input_path)
        sentences = open(output_path).read().split('\n\n')
        i=0
        for text_id,number_sentences in list_id_and_number_of_sentences:
            
            if number_sentences == 0:
                open(dir_path+os.sep+text_id,"w").write('')
            else:                
                open(dir_path+os.sep+text_id,"w").write('\n\n'.join(sentences[i:i+number_sentences])+'\n\n')
            i+=number_sentences
    
    
    
    def parse_to_file(self,output_path,tagged_sentences,aux_path="/tmp/output_parse_to_file.conll"):
        """
        @param output_path: The destination file.
        @param tagged_sentences: [tagged_sentence] where tagged_sentences is a [(token,L{INfoTag})]. 
        Use L{LexicalProcessor} to obtain them.
        @param aux_path: The path to an auxiliary file to parse the sentences.
        """
        self._preparator.prepare(aux_path,tagged_sentences)
        c = ConfigurationManager()
        os.chdir(c.getParameter("path_maltparser_model"))
        os.system("java -jar "+c.getParameter("path_maltparser")+" -c "+c.getParameter("maltparser_model")+
                  " -i "+aux_path+" -o "+output_path+" -m parse")   



    def parse_dir(self, list_of_tagged_sentences):
        list_id_and_number_of_sentences = [] #ID: number of sentences of the file (int) 
        list_id_and_dependency_graphs = []
        dir_tagged_sentences =[]
        for text_id, tagged_sentences in list_of_tagged_sentences:
            list_id_and_number_of_sentences.append((text_id,len(tagged_sentences))) 
            dir_tagged_sentences.extend(tagged_sentences)
        
        graphs = self.parse(dir_tagged_sentences)
        i=0
        for text_id,number_sentences in list_id_and_number_of_sentences:
            list_id_and_dependency_graphs.append((text_id, graphs[i:i+number_sentences]))
            i+=number_sentences
        return list_id_and_dependency_graphs
    
    
    
    def parse(self,tagged_sentences,input="/tmp/input.conll",output="/tmp/output.conll"):
        """
        @param tagged_sentences: [tagged_sentence] where tagged_sentences is a [(token,L{INfoTag})]. 
        Use L{LexicalProcessor} to obtain them.
        @param input: Temporal file to save the unparsed text.
        @param output: Temporal file to save the parsed text.
        @return: A [L{SentimentDependencyGraph}]
        """
        c = ConfigurationManager()
        self._preparator.prepare(input,tagged_sentences)
        os.chdir(c.getParameter("path_maltparser_model"))
        
        os.system("java -jar "+c.getParameter("path_maltparser")+" -c "+c.getParameter("maltparser_model")+" -i "+input+" -o "+output+" -m parse")
        sentences = self._simplify(output)
        return [SentimentDependencyGraph(s) for s in sentences]
    
    
    
    

    def _simplify(self,parsed_file):    
        """
        Simplifies a CoNLL 2006 file. The output is used to build instances of L{SentimentDependencyGraph}
        @param parsed_file: A path to a CoNLL 2006 file
        @return A list of dictionaries. Each dictionary saves a sentence of the file. ID is the key
        and the string FORM\tPOSTAG\tHEAD\tDEPREL is the value
        """
        co = codecs.open(parsed_file,encoding="utf-8")
        lines = co.readlines()
        sentence = {}
        sentences = []
        
        for l in lines:
            if len(l) > 1:
                columns = l.split('\t')
                t = TokenDependencyInfo(columns[1],columns[4],int(columns[6]),columns[7])
                sentence[int(columns[0])] = t
            else:
                sentences.append(sentence)
                sentence = {}
        co.close()
        return   self._format(self._reorganize(sentences))
        


    def _right_brothers(self,sentence,identifier):
        """
        @param sentence: An adversative sentence 
        @param identifier: ID of adversative clause
        @return: A list of right brothers id's of the adversative clause  
        """
        brothers = []
        father = sentence[identifier].get_head()
        
        for key in sentence.keys():
            if sentence[key].get_head() == father and key >= identifier:
                brothers.append(key)
        return brothers

  
  
    def _reorganize(self,sentences): 
        """
        Reorganizes the output_parsed CoNLL 2006 file to simplify the subordinating sentences
        @param sentences: A list of dictionaries. Each dictionaries is a sentence in CoNLL 2006
        representation. ID is the key and and the string FORM\tPOSTAG\tHEAD\tDEPREL is the value.
        """  
        for sentence in sentences:
            for key in sentence.keys():
                
                if self._is_symbolic_url(sentence[key]):
                    sentence = self._reorganize_symbolic_url(sentence, key)
                if self._is_emoticon(sentence[key]):
                    sentence = self._reorganize_emoticon(sentence, key)      
                if self._is_reorganizable_adversative(sentence[key]):
                    sentence = self._reorganize_adversative(sentence,key) 
        return sentences
    
    
    def _is_symbolic_url(self,token):
        """
        @param token: A L{TokenDependencyInfo} instance
        @return True is token form equals to 'SymbolicURL', False otherwise
        """
        return token.get_form() == 'SymbolicURL'
    
    
    def _reorganize_symbolic_url(self,sentence,key):
        """
        @precondition: The L{TokenDependencyInfo} sentence[key] must be a symbolic url
        @param sentence: A dictionary of L{TokenDependencyInfo}. Represents a sentence
        in CoNLL-2006. ID column is the key.
        @param key: ID of the symbolic url token
        @return A modified dictionary with modified information to the symbolic url token
        """
        sentence[key].set_deprel("art_rel_symbolicurl")
        sentence[key].set_finetag("symbolicurl:")
        return sentence
        
    
    
    def _is_emoticon(self,token):
        """
        @param token A L{TokenDependencyInfo} instance
        @return: True if token form is in set (['Emoticon-Negative','Emoticon-Positive',
                      'Extremely-Emoticon-Positive',
                      'Extremely-Emoticon-Negative',
                      'Neutral']), False otherwise
        """
        set_emoticons = set(['Emoticon-Negative','Emoticon-Positive',
                      'Extremely-Emoticon-Positive',
                      'Extremely-Emoticon-Negative',
                      'Neutral'])
        
        return token.get_form() in set_emoticons
    
    
    
    def _reorganize_emoticon(self,sentence,key):
        """
        @precondition: The L{TokenDependencyInfo} sentence[key] must be an emoticon
        @param sentence: A dictionary of L{TokenDependencyInfo}. Represents a sentence
        in CoNLL-2006. ID column is the key.
        @param key: ID of the emoticon token
        @return A modified dictionary with modified information to the symbolic emoticon token
        """
        sentence[key].set_deprel("art_rel_emoticon")
        sentence[key].set_finetag("emoticon:")
        return sentence



    def _is_reorganizable_adversative(self,token):
        """
        @param token: A L{TokenDependencyInfo} instance
        @return: True if token can be reorganized ('pero','sino','mientras','mientras_que','sino_que'), False otherwise
        """
        
        ladversatives = ['pero','sino','mientras','mientras_que','sino_que']
             
        return (token.get_finetag() == "c:postype_coordinating"
                and (token.get_form() in ladversatives)  
                and token.get_head() != 0 and token.get_deprel() == "coord")
     


    def _reorganize_adversative(self,sentence,key):
        """
        @precondition: Adversative clause must be reorganizable
        @param sentence: A dictionary of a sentence in CoNLL 2006. ID is the key and and the string FORM\tPOSTAG\tHEAD\tDEPREL is the value.
        @param key: ID of an adversative clause
        @return:
        """    
        head = sentence[key].get_head()
        artificial_id = len(sentence)+1
        form = sentence[key].get_form()
        artificial_node = TokenDependencyInfo("[]","art_adversative:"+self._type_of_adversative(form)+"@"+str(key),
                          sentence[head].get_head(),"art_rel_adversative")
        sentence[artificial_id] = artificial_node
        sentence[head].set_head(artificial_id)                
        right_brothers = self._right_brothers(sentence,key)
        for brother in right_brothers:
            sentence[brother].set_head(artificial_id)
        return sentence
 
    
    def _type_of_adversative(self,form):
        """
        @precondition: form must be in {'pero','sino','mientras','mientras_que','sino_que'}
        @param form: An adversative clause 
        @return: 'restrict' if the clause is restrictive, 'exclude' otherwise
        """
        if form in ['pero','mientras','mientras_que']:
            return 'restrict'
        else:
            return 'exclude'
            

    def _format(self,sentences):
        """
        Prepares a text to get a DependencyGraph instance
        """
        data_string = ""
        formatted_sentences = []
        
        for sentence in sentences:
            for key in sentence.keys():
                    token = sentence[key]
                    data_string = data_string+token.get_form()+'\t'+token.get_finetag() \
                    +'\t'+str(token.get_head())+'\t'+token.get_deprel()+'\n'
            formatted_sentences.append(data_string)        
            data_string = ""
        return formatted_sentences