'''
@author: david.vilares
'''

class ConfigurationManager(object):
    '''
    classdocs
    '''

    __parameters = {}
    #__pathconf = "/home/david/git/om_lys/miopia/miopia.conf"
    __pathconf = "/etc/miopia.conf" 

    __uniqueInstance = None   
        
    def __new__(self, *args, **kargs): 
        """
        Singleton
        """
        if self.__uniqueInstance is None:
            self.__uniqueInstance = object.__new__(self, *args, **kargs)
        return self.__uniqueInstance

    def __init__(self):
        '''
        Constructor
        '''
        conf_file = open(self.__pathconf,'r')
        list_of_parameters = conf_file.readlines()
        for parameter in list_of_parameters:
            aux = parameter.split('=')
            self.__parameters[aux[0]] = aux[1][0:len(aux[1])-1]
        
    def getParameter(self,parameter):
        try:
            return self.__parameters[parameter]
        except:
            return None


