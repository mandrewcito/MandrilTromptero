'''
Created on 20/05/2013

@author: david.vilares
'''

from miopia.adapter.NLPAdapter import NLPAdapter
from miopia.adapter.Feature import FeatureType
from miopia.util.exceptions.FeatureTypeConfigurationException import FeatureTypeConfigurationException

class PsychometricAdapter(NLPAdapter):
    '''
    PsychometricAdapter allows to obtain psychometric features to then train a L{ClassifierI}
    '''


    def __init__(self,float_threshold, feature_type_configuration,
                 path_weka, arff_file='/tmp/PsychometricAdapter.arff'):
        """
        @param float_threshold: An information gain threshold (minimum) for selecting features
        @param feature_type_configuration: An instance of L{src.miope.adapter.Feature.FeatureTypeConfiguration}
        @param path_weka: A path to the weka jar
        @param arff_file: A path to the destination arff file
        @precondition: L{src.miope.adapter.Feature.FeatureTypeConfiguration} add_dependency_type,
        back_off_head, back_off_dependent, n_gram and n_gram_back_off attributes must be None.
        """
        if (feature_type_configuration.get_n_gram() != None
            or feature_type_configuration.get_add_dependency_type() != None
            or feature_type_configuration.get_back_off_head() != None
            or feature_type_configuration.get_back_off_dependent() != None
            or feature_type_configuration.get_n_gram_back_off() != None):
            raise FeatureTypeConfigurationException(str(PsychometricAdapter)+': parameters not applicable')
        
        super(PsychometricAdapter,self).__init__(float_threshold,
                                                 feature_type_configuration,
                                                 path_weka,arff_file)
        
    
    def _get_feature_type(self):
        """
        The type of the feature
        """
        return FeatureType.PSYCHOMETRIC
    
    def _analyze_graph(self,dg):
        """
        @param dg: An instance of L{SentimentDependencyGraph}
        @return: A dictionary with the number of features considered by the adapter in an instance
        of a L{SentimentDependencyGraph} 
        """
        return self._linguistic_analyzer.count_psychometrics(dg, 0, self._feature_type_configuration)