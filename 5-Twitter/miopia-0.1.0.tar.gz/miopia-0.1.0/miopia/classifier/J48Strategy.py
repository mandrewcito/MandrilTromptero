'''
Created on 31/01/2013

@author: David Vilares Calvo
'''

import os
import codecs
from miopia.classifier.WekaClassificationStrategy import WekaClassificationStrategy


class J48Strategy(WekaClassificationStrategy):
    '''
    classdocs
    '''

    def __init__(self,classes, list_word_features,path_weka=None,
                 input_arff="/tmp/weka_classifier_input.arff", results_file="/tmp/outputJ48.txt",model=None):
        '''
        Constructor
        @param classes: A list of L{PolarityType}. Each element represents a class. No duplicates
        @param path_weka: A path to the weka.jar. None if weka is in your classpath
        @param model: A path to a trained model (not xml). If None, a model must
        be trained using train() method.
        '''
        super(J48Strategy,self).__init__(classes, list_word_features,path_weka,input_arff,results_file,model)
        
        
            
    def _train_model(self,arff_training_file):
        """
        @param arff_training_file: Path to training file in ARFF format
        @param output_model: Path to the output model file
        @param path_to_weka: Path to weka.jar. None if weka.jar is in the CLASSPATH
        """
        #TODO: train() if weka not in claspath
        os.system("java -cp "+self._path_weka+" weka.classifiers.trees.J48 -v -o -i -t "
                  +arff_training_file+" -d "+self._model)
            
            
                
    def _get_model_classifications(self):
        """
        @param list_sentiment_info: A list of tuples (textID,L{SentimentInfo})
        @return: A list of tuples (textID,L{PolarityType})
        """
            
        os.system("java -cp "+self._path_weka+" weka.classifiers.trees.J48 "+
        "-classifications \"weka.classifiers.evaluation.output.prediction.PlainText "
        "-file "+self._results_file+" -decimals 15 -suppress \" "+ 
        "-l "+self._model+" -T "+self._input_arff)      
        lines = open(self._results_file,"r").readlines()
        return lines[1:len(lines)-1]

            
        
        