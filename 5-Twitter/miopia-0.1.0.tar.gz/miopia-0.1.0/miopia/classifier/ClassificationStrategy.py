'''
Created on 29/01/2013

@author: David Vilares Calvo
'''


class ClassificationStrategy(object):
    '''
    classdocs
    '''


    def __init__(self,threshold):
        '''
        Constructor
        '''
        self._threshold = threshold
   
    
    def _type(self,sentiment_info):
        raise NotImplementedError
    
    
    def polarity_info(self,info,**kwargs):
        return self._type(info)


    def polarity(self,list_info,**kwargs):   
        """
        @param list_info: A list of tuples (textID,L{SentimentInfo})
        @return: A list of tuples (textID,L{PolarityType})
        """ 
        polarities = []      
        for (f,sentiment_info) in list_info:
            polarities.append((f, self.polarity_text(sentiment_info)))
        return polarities   
