'''
Created on 04/02/2013

@author: David Vilares
'''

from miopia.classifier.ClassificationStrategy import ClassificationStrategy
import codecs

class AttributeEvaluator(object):
    
    def __init__(self):
        pass    
        
class InformationGainAttributeEvaluator(AttributeEvaluator):
    INFORMATION_GAIN = "weka.attributeSelection.InfoGainAttributeEval"
    
    def __init__(self):
        super(InformationGainAttributeEvaluator,self).__init__()
    
    def __str__(self):
        return self.INFORMATION_GAIN
    
    
    
class PrincipalComponentsAttributeEvaluator(AttributeEvaluator):
    PRINCIPAL_COMPONENTS = "weka.attributeSelection.PrincipalComponents"
        
    def __init__(self, variance_covered =0.95):
        super(PrincipalComponentsAttributeEvaluator,self).__init__()
        self._variance_covered = variance_covered
    
    def __str__(self):
        return self.PRINCIPAL_COMPONENTS
        
        
class SearchMethod(object):

    def __init__(self):
        pass

class RankerSearchMethod(SearchMethod):
    
    RANKER = "weka.attributeSelection.Ranker"

    def __init__(self, threshold = 0., num_to_select = -1):
        super(RankerSearchMethod,self).__init__()
        self._threshold = threshold
        self._num_to_select = num_to_select
         
    def __str__(self):
        return self.RANKER+" -T "+str(self._threshold)+" -N "+str(self._num_to_select)


class ClassifierWeka(object):
    SMO = "weka.classifiers.functions.SMO"
    NAIVE_BAYES = "weka.classifiers.bayes.NaiveBayes"
    META_CLASSIFIER = "weka.classifiers.meta.AttributeSelectedClassifier"


class WekaClassificationStrategy(ClassificationStrategy):
    '''
    classdocs
    '''
    UNKWOWN_CLASS_SYMBOL = '?'
            
    def __init__(self,classes, path_weka,input_arff, results_file, model):
        '''
        Constructor
        @param classes: A list of L{PolarityType}. Each element represents a class. No duplicates
        @param path_weka
        @param input_arff: A path to the destination input file of the classifier
        @param model: A path to a trained model
        '''
        self._classes = classes
        self._input_arff = input_arff
        self._results_file = results_file
        self._model = model
        if path_weka is None: self._path_weka = ''
        else: self._path_weka = path_weka


    def _to_arff(self,list_linguistic_info, dict_adapted_features,
                 arff_file):
        farff = codecs.open(arff_file,"w",'utf-8')
        farff.write("@RELATION Polarity\n")
        arff_data = ''
        close_symbol = "}"
        
        dict_id_features = {}
        id_feature = 0
        for feature_type, ftc in dict_adapted_features.keys():        
                for feature_name in dict_adapted_features[feature_type,ftc]:
                    farff.write("@ATTRIBUTE '"+feature_type+str(ftc)+feature_name+"' "+ftc.get_weka_data_type()+"\n")
                    dict_id_features[feature_type+str(ftc)+feature_name] = id_feature
                    id_feature+=1
        farff.write("@ATTRIBUTE 'class' {"+','.join(self._classes)+"}\n")
        farff.write("@DATA\n")     
              
        for linguistic_info, category in list_linguistic_info:
            arff_data= ""
            open_symbol = "{"
            dict_appeared_features = {f.get_type()+str(f.get_type_configuration())+f.get_name():f.get_value() 
                                      for f in linguistic_info.get_features()}
            
            keys = dict_appeared_features.keys()
            keys.sort(key = lambda x: dict_id_features[x]) 
            
            for feature_in_text in keys:                             
                arff_data+=open_symbol+str(dict_id_features[feature_in_text])+" "+str(dict_appeared_features[feature_in_text])+","    
                open_symbol = ""
            arff_data+=open_symbol+str(id_feature)+" "+" "+category+close_symbol+'\n'
            farff.write(arff_data)      

        farff.close()  

             
    def train(self,list_linguistic_info_category,dict_adapted_features,
               arff_training_file, output_model):
        """
        @param list_linguistic_info_category: A list of tuples (L{LinguisticInfo},category) where 
        category represents the class
        @param dict_adapted_features: A dictionary {L{FeatureType,FeatureTypeConfiguration}: name_of_feature}. 
        Use the methods adapt or adapt_from_ranking file of L{Adapter} to obtain it.
        @param arff_training_file: Path to resulting training file in ARFF format
        @param output_model: Path to the output model file
        """
        self._to_arff(list_linguistic_info_category, dict_adapted_features, arff_training_file)
        self._model = output_model
        self._train_model(arff_training_file)

#     def train(self,arff_training_file, output_model):
#         """
#         @param arff_training_file: Path to training file in ARFF format
#         @param output_model: Path to the output model file
#         @param path_to_weka: Path to weka.jar. None if weka.jar is in the CLASSPATH
#         """
#         print "Entrenando"
#         self._model = output_model
#         self._train_model(arff_training_file)
        
#         
        
    def polarity_info(self,info,**kwargs):
        """
        @param info: Either a L{SentimentInfo} or a L{LinguisticInfo}
        @param **kwargs: Optional key 'dict_adapted_features' to include
        the dictionary of the adapted features that a L{LinguisticInfo} should match.
        @return: A L{PolarityType}
        """
        dict_adapted_features = kwargs['dict_adapted_features']
        self._to_arff([(info,self.UNKWOWN_CLASS_SYMBOL)], dict_adapted_features,
                      self._input_arff)
        lines= self._get_model_classifications()
        return lines[0].split()[2].split(":")[1]        


    def polarity(self,list_linguistic_info, **kwargs):
        """
        @param info: Either a L{SentimentInfo} or a L{LinguisticInfo}
        @param **kwargs: Optional key 'dict_adapted_features' to include
        the dictionary of the adapted features that a L{LinguisticInfo} should match.
        @return: A L{PolarityType}
        """
        dict_adapted_features = kwargs['dict_adapted_features']
        polarities = []
        self._to_arff([(linguistic_info[1],self.UNKWOWN_CLASS_SYMBOL) 
                       for linguistic_info in list_linguistic_info], dict_adapted_features,
                      self._input_arff)
        lines= self._get_model_classifications()
        i=0
        for line in lines:
            polarities.append((list_linguistic_info[i][0],line.split()[2].split(":")[1], line.split()[3]))
            i+=1
        return polarities


        