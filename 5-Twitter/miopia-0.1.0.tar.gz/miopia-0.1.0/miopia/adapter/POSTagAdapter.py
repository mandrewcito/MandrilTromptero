'''
Created on 10/04/2013

@author: David Vilares
'''

from miopia.adapter.Feature import FeatureType
from miopia.adapter.NLPAdapter import NLPAdapter
from miopia.util.exceptions.FeatureTypeConfigurationException import FeatureTypeConfigurationException


class POSTagAdapter(NLPAdapter):
    '''
    POSTagAdapter allows to obtain PoS-tag features to then train a L{ClassifierI}
    '''

    def __init__(self, fine_tag, float_threshold,feature_type_configuration,
                 path_weka, arff_file='/tmp/POSTagAdapter.arff'):
        '''
        @param fine_tag: A boolean indicating if the adapter must obtain coarse or fine tags.
        @param float_threshold: An information gain threshold (minimum) for selecting features
        @param feature_type_configuration: An instance of L{src.miope.adapter.Feature.FeatureTypeConfiguration}
        @param path_weka: A path to the weka jar
        @param arff_file: A path to the destination arff file
        @precondition: L{src.miope.adapter.Feature.FeatureTypeConfiguration} n_gram,
        add_dependency_type, back_off_head, back_off_dependent and n_gram_back_off attributes must be None
        '''
        
        if (feature_type_configuration.get_n_gram() != None
            or feature_type_configuration.get_add_dependency_type() != None
            or feature_type_configuration.get_back_off_head() != None
            or feature_type_configuration.get_back_off_dependent() != None
            or feature_type_configuration.get_n_gram_back_off() != None):
            raise FeatureTypeConfigurationException(str(POSTagAdapter)+': parameters not applicable')
        
        self._fine_tag = fine_tag
        super(POSTagAdapter,self).__init__(float_threshold,
                                           feature_type_configuration,
                                           path_weka,arff_file)
    
    
    def _get_feature_type(self):
        """
        The type of the feature
        """
        if self._fine_tag:
            return FeatureType.FINE_POSTAG
        return FeatureType.CROSS_POSTAG


    def _analyze_graph(self,dg):
        """
        @param dg: An instance of L{SentimentDependencyGraph}
        @return: A dictionary with the number of features considered by the adapter in an instance
        of a L{SentimentDependencyGraph} 
        """
        if self._fine_tag:
            return self._linguistic_analyzer.count_fine_postags(dg, 0,
                                                                self.get_feature_type_configuration())
        return self._linguistic_analyzer.count_cross_postags(dg, 0,
                                                             self.get_feature_type_configuration())
                
                