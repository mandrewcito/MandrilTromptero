'''
Created on 29/01/2013

@author: David Vilares Calvo
'''

from miopia.classifier.ClassificationStrategy import ClassificationStrategy
from miopia.classifier.PolarityType import PolarityType

class TernaryStrategy(ClassificationStrategy):
    '''
    This strategy allows to classify texts such as Positive, Negative
    or None (without any sentiment)
    '''


    def __init__(self,threshold):
        '''
        Constructor
        @param threshold: A float. It establish a numerical threshold to distinguish between classes  
        '''
        super(TernaryStrategy,self).__init__(threshold)
        
        
    def _type(self, sentiment_info):
        """
        @param sentiment_info: A L{SentimentInfo} object
        @return: A L{PolarityType} value in {NEGATIVE, POSITIVE, NONE}
        """
        so = sentiment_info.get_so()

        if so > self._threshold: return PolarityType.POSITIVE
        if so < self._threshold: return PolarityType.NEGATIVE
        return PolarityType.NONE

