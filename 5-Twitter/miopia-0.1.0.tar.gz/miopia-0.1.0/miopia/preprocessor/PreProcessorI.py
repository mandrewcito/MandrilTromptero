'''
@author: David Vilares Calvo
'''

class PreProcessorI(object):
    '''
    A preprocessing interface for texts
    '''

    def __init__(self,params):
        raise NotImplementedError
        
    def preprocess(self,text):
        raise NotImplementedError
        