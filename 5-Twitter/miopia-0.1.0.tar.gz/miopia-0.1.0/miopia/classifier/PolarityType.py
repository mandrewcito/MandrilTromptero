'''
Created on 29/01/2013

@author: David Vilares
'''

class PolarityType(object):
    '''
    The supported polarity classes by the system
    '''
    STRONG_NEGATIVE = 'N+'
    NEGATIVE = 'N'
    NEUTRAL = 'NEU'
    NONE = 'NONE'
    POSITIVE = 'P'
    STRONG_POSITIVE = 'P+'
    OTHER = 'OTHER'
        